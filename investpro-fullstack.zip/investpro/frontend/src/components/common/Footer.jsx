import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Twitter, Linkedin, Github, Mail, Shield, Award, Globe } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-dark-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center">
                <TrendingUp size={18} className="text-white" />
              </div>
              <span className="font-bold text-xl text-white">Invest<span className="text-brand-400">Pro</span></span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
              Smart investment solutions for modern investors. Secure, transparent, and profitable.
            </p>
            <div className="flex gap-3">
              {[Twitter, Linkedin, Github].map((Icon, i) => (
                <button key={i} className="w-9 h-9 glass rounded-lg flex items-center justify-center text-slate-400 hover:text-brand-400 hover:border-brand-500/30 transition-all">
                  <Icon size={16} />
                </button>
              ))}
            </div>
          </div>

          {[
            { title: 'Company', links: [['About Us', '/about'], ['Investment Plans', '/plans'], ['Contact', '/contact']] },
            { title: 'Account', links: [['Sign In', '/login'], ['Register', '/register'], ['Dashboard', '/dashboard']] },
            { title: 'Legal', links: [['Privacy Policy', '#'], ['Terms of Service', '#'], ['Risk Disclosure', '#']] },
          ].map(col => (
            <div key={col.title}>
              <h4 className="text-white font-semibold mb-4">{col.title}</h4>
              <ul className="space-y-3">
                {col.links.map(([label, href]) => (
                  <li key={label}><Link to={href} className="text-slate-400 hover:text-brand-400 text-sm transition-colors">{label}</Link></li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-sm">© 2025 InvestPro. All rights reserved.</p>
          <div className="flex items-center gap-6 text-slate-500 text-xs">
            {[Shield, Award, Globe].map((Icon, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <Icon size={13} className="text-brand-500" />
                <span>{['SSL Secured', 'Licensed & Regulated', 'Global Platform'][i]}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
