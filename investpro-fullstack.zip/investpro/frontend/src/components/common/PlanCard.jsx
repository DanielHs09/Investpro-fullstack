import React from 'react';
import { Check, ArrowRight, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function PlanCard({ plan, featured = false }) {
  const { user } = useAuth();
  const totalReturn = (plan.roiPercent * plan.durationDays).toFixed(0);

  return (
    <div className={`relative rounded-2xl p-6 transition-all duration-300 hover:scale-[1.02] group ${
      featured
        ? 'bg-gradient-to-br from-brand-500/20 to-brand-900/20 border-2 border-brand-500/40 shadow-2xl glow-brand'
        : 'glass border border-white/5 hover:border-brand-500/20'
    }`}>
      {plan.badge && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="gradient-brand text-white text-xs font-bold px-4 py-1.5 rounded-full flex items-center gap-1">
            <Zap size={12} /> {plan.badge}
          </span>
        </div>
      )}

      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: plan.color + '22' }}>
          <div className="w-4 h-4 rounded-full" style={{ background: plan.color }} />
        </div>
        <div>
          <h3 className="font-bold text-white text-lg">{plan.name}</h3>
          <p className="text-slate-400 text-xs">{plan.description}</p>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-1">
          <span className="text-4xl font-bold text-white">{plan.roiPercent}%</span>
          <span className="text-slate-400 text-sm">daily ROI</span>
        </div>
        <div className="flex items-center gap-4 mt-2">
          <span className="text-brand-400 text-sm font-semibold">{totalReturn}% total return</span>
          <span className="text-slate-500 text-xs">in {plan.durationDays} days</span>
        </div>
      </div>

      <div className="bg-white/5 rounded-xl p-3 mb-5 flex justify-between">
        <div><p className="text-xs text-slate-400">Min</p><p className="text-white font-semibold">${plan.minAmount.toLocaleString()}</p></div>
        <div className="w-px bg-white/10" />
        <div><p className="text-xs text-slate-400">Max</p><p className="text-white font-semibold">${plan.maxAmount.toLocaleString()}</p></div>
        <div className="w-px bg-white/10" />
        <div><p className="text-xs text-slate-400">Duration</p><p className="text-white font-semibold">{plan.durationDays}d</p></div>
      </div>

      <ul className="space-y-2 mb-6">
        {plan.features?.slice(0,5).map((f, i) => (
          <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
            <Check size={14} className="text-brand-400 flex-shrink-0" /> {f}
          </li>
        ))}
      </ul>

      <Link to={user ? '/dashboard/deposit' : '/register'}
        className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all group-hover:gap-3 ${
          featured ? 'gradient-brand text-white glow-brand' : 'border border-brand-500/40 text-brand-400 hover:bg-brand-500/10'
        }`}>
        {user ? 'Invest Now' : 'Get Started'} <ArrowRight size={16} />
      </Link>
    </div>
  );
}
