import React from 'react';

export default function StatCard({ label, value, icon: Icon, change, color = 'brand', prefix = '', suffix = '' }) {
  const colors = {
    brand: 'text-brand-400 bg-brand-500/10 border-brand-500/20',
    blue: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
    purple: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
    amber: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
    red: 'text-red-400 bg-red-500/10 border-red-500/20',
  };
  const c = colors[color] || colors.brand;
  const [iconColor, bgColor] = c.split(' ');

  return (
    <div className="glass rounded-2xl p-5 stat-card border border-white/5">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${bgColor} ${c.split(' ')[2]}`}>
          <Icon size={18} className={iconColor} />
        </div>
        {change !== undefined && (
          <span className={`text-xs font-medium px-2 py-1 rounded-full ${change >= 0 ? 'text-brand-400 bg-brand-500/10' : 'text-red-400 bg-red-500/10'}`}>
            {change >= 0 ? '+' : ''}{change}%
          </span>
        )}
      </div>
      <p className="text-slate-400 text-xs mb-1">{label}</p>
      <p className="text-2xl font-bold text-white">{prefix}{typeof value === 'number' ? value.toLocaleString() : value}{suffix}</p>
    </div>
  );
}
