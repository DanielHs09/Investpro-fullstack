import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { TrendingUp, Menu, X, Sun, Moon, Bell, User, LogOut, LayoutDashboard } from 'lucide-react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/plans', label: 'Investment Plans' },
    { to: '/about', label: 'About' },
    { to: '/contact', label: 'Contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'glass border-b border-white/5 shadow-2xl' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center glow-brand-sm group-hover:scale-110 transition-transform">
              <TrendingUp size={18} className="text-white" />
            </div>
            <span className="font-bold text-xl text-white">Invest<span className="text-brand-400">Pro</span></span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map(link => (
              <Link key={link.to} to={link.to}
                className={`nav-link text-sm font-medium transition-colors ${
                  location.pathname === link.to ? 'text-brand-400 active' : 'text-slate-300 hover:text-white'
                }`}>{link.label}</Link>
            ))}
          </div>

          {/* Right side */}
          <div className="hidden md:flex items-center gap-3">
            <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-all">
              {isDark ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {user ? (
              <div className="relative">
                <button onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 glass px-3 py-2 rounded-xl hover:bg-white/5 transition-all">
                  <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center">
                    <span className="text-xs font-bold text-white">{user.firstName?.[0]}{user.lastName?.[0]}</span>
                  </div>
                  <span className="text-sm text-white font-medium">{user.firstName}</span>
                </button>
                {userMenuOpen && (
                  <div className="absolute right-0 top-full mt-2 w-52 glass rounded-xl border border-white/10 shadow-xl overflow-hidden animate-slide-up">
                    <div className="px-4 py-3 border-b border-white/5">
                      <p className="text-sm font-semibold text-white">{user.firstName} {user.lastName}</p>
                      <p className="text-xs text-slate-400">{user.email}</p>
                    </div>
                    <Link to={user.role === 'admin' ? '/admin' : '/dashboard'} onClick={() => setUserMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 text-sm text-slate-300 hover:text-white hover:bg-white/5 transition-colors">
                      <LayoutDashboard size={15} /> Dashboard
                    </Link>
                    <Link to="/dashboard/profile" onClick={() => setUserMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 text-sm text-slate-300 hover:text-white hover:bg-white/5 transition-colors">
                      <User size={15} /> Profile
                    </Link>
                    <button onClick={() => { logout(); setUserMenuOpen(false); }}
                      className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors">
                      <LogOut size={15} /> Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <Link to="/login" className="text-sm text-slate-300 hover:text-white transition-colors font-medium">Sign In</Link>
                <Link to="/register" className="gradient-brand text-white text-sm font-semibold px-5 py-2 rounded-xl hover:opacity-90 transition-all glow-brand-sm">
                  Get Started
                </Link>
              </div>
            )}
          </div>

          {/* Mobile toggle */}
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2 text-slate-300 hover:text-white">
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden glass border-t border-white/5 animate-slide-up">
          <div className="px-4 py-4 space-y-2">
            {navLinks.map(link => (
              <Link key={link.to} to={link.to} onClick={() => setMenuOpen(false)}
                className="block py-3 text-slate-300 hover:text-white font-medium border-b border-white/5">
                {link.label}
              </Link>
            ))}
            {user ? (
              <div className="pt-2 space-y-2">
                <Link to={user.role === 'admin' ? '/admin' : '/dashboard'} onClick={() => setMenuOpen(false)}
                  className="block py-3 text-brand-400 font-semibold">Dashboard</Link>
                <button onClick={() => { logout(); setMenuOpen(false); }} className="block w-full text-left py-3 text-red-400">Sign Out</button>
              </div>
            ) : (
              <div className="pt-2 flex gap-3">
                <Link to="/login" onClick={() => setMenuOpen(false)} className="flex-1 text-center py-3 border border-white/10 rounded-xl text-slate-300">Sign In</Link>
                <Link to="/register" onClick={() => setMenuOpen(false)} className="flex-1 text-center py-3 gradient-brand rounded-xl text-white font-semibold">Get Started</Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
