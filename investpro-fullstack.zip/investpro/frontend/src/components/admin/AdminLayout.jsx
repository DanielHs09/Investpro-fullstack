import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, History, Settings, LogOut, Menu, X, TrendingUp, Shield } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const navItems = [
  { to: '/admin', icon: LayoutDashboard, label: 'Dashboard', exact: true },
  { to: '/admin/users', icon: Users, label: 'Users' },
  { to: '/admin/transactions', icon: History, label: 'Transactions' },
  { to: '/admin/plans', icon: TrendingUp, label: 'Plans' },
];

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const isActive = (item) => item.exact ? location.pathname === item.to : location.pathname.startsWith(item.to);

  return (
    <div className="min-h-screen bg-dark-900 flex">
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 glass border-r border-white/5 fixed h-full z-30">
        <div className="p-6 border-b border-white/5">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center"><Shield size={16} className="text-white" /></div>
            <span className="font-bold text-lg text-white">Admin <span className="text-brand-400">Panel</span></span>
          </div>
          <p className="text-xs text-slate-500">InvestPro Management</p>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(item => (
            <Link key={item.to} to={item.to}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${isActive(item) ? 'gradient-brand text-white glow-brand-sm' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}>
              <item.icon size={18} /> {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5">
          <Link to="/dashboard" className="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm text-slate-400 hover:text-white hover:bg-white/5 mb-1 transition-colors">
            <LayoutDashboard size={16} /> User Dashboard
          </Link>
          <button onClick={() => { logout(); navigate('/login'); }} className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm text-red-400 hover:bg-red-500/10 transition-colors">
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </aside>

      {open && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <div className="relative w-64 glass border-r border-white/5 h-full">
            <button onClick={() => setOpen(false)} className="absolute top-4 right-4 text-slate-400"><X size={20} /></button>
            <div className="p-6 pt-16 space-y-1">
              {navItems.map(item => (
                <Link key={item.to} to={item.to} onClick={() => setOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${isActive(item) ? 'gradient-brand text-white' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}>
                  <item.icon size={18} /> {item.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 lg:ml-64 flex flex-col">
        <header className="glass border-b border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-20">
          <button onClick={() => setOpen(true)} className="lg:hidden text-slate-400"><Menu size={22} /></button>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-brand-400 rounded-full animate-pulse" />
            <span className="text-slate-400 text-sm">Admin Mode</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center text-white text-xs font-bold">
              {user?.firstName?.[0]}
            </div>
            <span className="text-white text-sm font-medium hidden sm:block">{user?.firstName}</span>
          </div>
        </header>
        <main className="flex-1 p-6"><Outlet /></main>
      </div>
    </div>
  );
}
