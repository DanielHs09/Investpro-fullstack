import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, TrendingUp, ArrowDownCircle, ArrowUpCircle, History, User, LogOut, Menu, X, Bell, TrendingDown } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard', exact: true },
  { to: '/dashboard/investments', icon: TrendingUp, label: 'Investments' },
  { to: '/dashboard/deposit', icon: ArrowDownCircle, label: 'Deposit' },
  { to: '/dashboard/withdraw', icon: ArrowUpCircle, label: 'Withdraw' },
  { to: '/dashboard/transactions', icon: History, label: 'Transactions' },
  { to: '/dashboard/profile', icon: User, label: 'Profile' },
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  const isActive = (item) => item.exact ? location.pathname === item.to : location.pathname.startsWith(item.to);

  const Sidebar = ({ mobile = false }) => (
    <div className={`flex flex-col h-full ${mobile ? '' : 'w-64'}`}>
      <div className="p-6 border-b border-white/5">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center"><TrendingDown size={16} className="text-white" /></div>
          <span className="font-bold text-lg text-white">Invest<span className="text-brand-400">Pro</span></span>
        </Link>
      </div>
      <div className="p-4 border-b border-white/5">
        <div className="bg-brand-500/10 rounded-xl p-3 border border-brand-500/20">
          <p className="text-xs text-slate-400 mb-1">Wallet Balance</p>
          <p className="text-2xl font-bold text-white">${(user?.walletBalance || 0).toLocaleString()}</p>
        </div>
      </div>
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map(item => (
          <Link key={item.to} to={item.to} onClick={() => setSidebarOpen(false)}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              isActive(item) ? 'gradient-brand text-white glow-brand-sm' : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}>
            <item.icon size={18} /> {item.label}
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-white/5">
        <div className="flex items-center gap-3 mb-3 px-2">
          <div className="w-9 h-9 gradient-brand rounded-xl flex items-center justify-center text-white font-bold text-sm">
            {user?.firstName?.[0]}{user?.lastName?.[0]}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate">{user?.firstName} {user?.lastName}</p>
            <p className="text-xs text-slate-400 truncate">{user?.email}</p>
          </div>
        </div>
        <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm text-red-400 hover:bg-red-500/10 transition-colors">
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-dark-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 glass border-r border-white/5 fixed h-full z-30">
        <Sidebar />
      </aside>

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-72 glass border-r border-white/5 h-full flex flex-col">
            <button onClick={() => setSidebarOpen(false)} className="absolute top-4 right-4 text-slate-400"><X size={20} /></button>
            <Sidebar mobile />
          </div>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        <header className="glass border-b border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-20">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-slate-400 hover:text-white"><Menu size={22} /></button>
          <div className="hidden lg:block">
            <h1 className="text-white font-semibold capitalize">
              {location.pathname === '/dashboard' ? 'Dashboard' : location.pathname.split('/').pop()}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-2 text-slate-400 hover:text-white relative">
              <Bell size={18} />
              {user?.notifications?.filter(n => !n.read).length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-brand-400 rounded-full" />
              )}
            </button>
          </div>
        </header>
        <main className="flex-1 p-6"><Outlet /></main>
      </div>
    </div>
  );
}
