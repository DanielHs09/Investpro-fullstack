import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, TrendingUp, ArrowRight, User, Mail, Lock, Phone, Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', password: '', phone: '', country: '' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.firstName || !form.email || !form.password) return toast.error('Please fill required fields');
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters');
    setLoading(true);
    try {
      const user = await register(form);
      toast.success(`Welcome to InvestPro, ${user.firstName}!`);
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally { setLoading(false); }
  };

  const Field = ({ name, label, type = 'text', icon: Icon, placeholder, required = false }) => (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">{label}{required && <span className="text-red-400 ml-1">*</span>}</label>
      <div className="relative">
        <Icon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input type={type} name={name} value={form[name]} onChange={handle} placeholder={placeholder}
          className="w-full bg-dark-700 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 transition-colors" />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-dark-900 gradient-hero flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg animate-fade-in">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center glow-brand">
              <TrendingUp size={20} className="text-white" />
            </div>
            <span className="font-bold text-2xl text-white">Invest<span className="text-brand-400">Pro</span></span>
          </Link>
          <h1 className="text-3xl font-bold text-white mb-2">Create Account</h1>
          <p className="text-slate-400">Start your investment journey today</p>
        </div>

        <div className="glass rounded-2xl p-8 border border-white/5">
          <form onSubmit={submit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Field name="firstName" label="First Name" icon={User} placeholder="John" required />
              <Field name="lastName" label="Last Name" icon={User} placeholder="Doe" />
            </div>
            <Field name="email" label="Email" type="email" icon={Mail} placeholder="you@example.com" required />
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Password <span className="text-red-400">*</span></label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input type={showPw ? 'text' : 'password'} name="password" value={form.password} onChange={handle} placeholder="Min 6 characters"
                  className="w-full bg-dark-700 border border-white/10 rounded-xl pl-10 pr-12 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 transition-colors" />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field name="phone" label="Phone" icon={Phone} placeholder="+1 234 567 890" />
              <Field name="country" label="Country" icon={Globe} placeholder="United States" />
            </div>

            <div className="text-xs text-slate-500 bg-dark-700 rounded-xl p-3">
              By registering, you agree to our Terms of Service and Privacy Policy. Investments involve risk.
            </div>

            <button type="submit" disabled={loading}
              className="w-full gradient-brand text-white font-bold py-3.5 rounded-xl glow-brand hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Create Account <ArrowRight size={18} /></>}
            </button>
          </form>

          <p className="text-center text-slate-400 text-sm mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-brand-400 hover:text-brand-300 font-semibold">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
