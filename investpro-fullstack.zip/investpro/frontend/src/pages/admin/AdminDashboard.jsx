import React, { useState, useEffect } from 'react';
import { Users, DollarSign, TrendingUp, Clock, CheckCircle, XCircle, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { adminAPI } from '../../services/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const chartData = [
  { month: 'Jan', deposits: 12000, withdrawals: 4000 },
  { month: 'Feb', deposits: 18000, withdrawals: 6000 },
  { month: 'Mar', deposits: 15000, withdrawals: 5500 },
  { month: 'Apr', deposits: 22000, withdrawals: 7000 },
  { month: 'May', deposits: 28000, withdrawals: 9000 },
  { month: 'Jun', deposits: 35000, withdrawals: 12000 },
];

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.getStats().then(r => setData(r.data)).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-10 h-10 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" /></div>;

  const stats = data?.stats || {};
  const cards = [
    { label: 'Total Users', value: stats.totalUsers || 0, icon: Users, color: 'text-brand-400 bg-brand-500/10' },
    { label: 'Total Invested', value: `$${(stats.totalDeposited || 0).toLocaleString()}`, icon: DollarSign, color: 'text-blue-400 bg-blue-500/10' },
    { label: 'Active Investments', value: stats.totalInvestments || 0, icon: TrendingUp, color: 'text-amber-400 bg-amber-500/10' },
    { label: 'Pending Deposits', value: stats.pendingDeposits || 0, icon: Clock, color: 'text-orange-400 bg-orange-500/10', alert: stats.pendingDeposits > 0 },
    { label: 'Pending Withdrawals', value: stats.pendingWithdrawals || 0, icon: Clock, color: 'text-red-400 bg-red-500/10', alert: stats.pendingWithdrawals > 0 },
    { label: 'Active Plans', value: stats.activePlans || 0, icon: CheckCircle, color: 'text-purple-400 bg-purple-500/10' },
  ];

  const statusBadge = (s) => {
    const m = { pending: 'bg-amber-500/10 text-amber-400', approved: 'bg-brand-500/10 text-brand-400', completed: 'bg-brand-500/10 text-brand-400', rejected: 'bg-red-500/10 text-red-400' };
    return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${m[s] || ''}`}>{s}</span>;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold text-white">Admin Dashboard</h2>
        <p className="text-slate-400 text-sm mt-1">Platform overview and management</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((c, i) => (
          <div key={i} className={`glass rounded-2xl p-5 border transition-all ${c.alert ? 'border-amber-500/30 shadow-amber-500/10 shadow-lg' : 'border-white/5'}`}>
            <div className={`w-10 h-10 ${c.color} rounded-xl flex items-center justify-center mb-3`}>
              <c.icon size={18} className={c.color.split(' ')[0]} />
            </div>
            <p className="text-slate-400 text-xs mb-1">{c.label}</p>
            <p className="text-2xl font-bold text-white">{c.value}</p>
            {c.alert && <p className="text-amber-400 text-xs mt-1 font-medium">⚠ Action required</p>}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart */}
        <div className="glass rounded-2xl p-6 border border-white/5">
          <h3 className="font-semibold text-white mb-5">Monthly Flow (USD)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={chartData}>
              <XAxis dataKey="month" stroke="#475569" tick={{ fontSize: 11 }} />
              <YAxis stroke="#475569" tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ background: '#0d1530', border: '1px solid rgba(0,196,143,0.2)', borderRadius: '12px', color: '#f1f5f9' }} />
              <Bar dataKey="deposits" fill="#00C48F" radius={[4,4,0,0]} />
              <Bar dataKey="withdrawals" fill="#ef4444" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Transactions */}
        <div className="glass rounded-2xl border border-white/5 overflow-hidden">
          <div className="p-4 border-b border-white/5 flex justify-between items-center">
            <h3 className="font-semibold text-white">Recent Transactions</h3>
            <Link to="/admin/transactions" className="text-brand-400 text-xs flex items-center gap-1">View All <ArrowRight size={12} /></Link>
          </div>
          <div className="divide-y divide-white/5">
            {(data?.recentTransactions || []).slice(0,6).map(tx => (
              <div key={tx._id} className="px-4 py-3 flex items-center justify-between">
                <div>
                  <p className="text-white text-sm">{tx.user?.firstName} {tx.user?.lastName}</p>
                  <p className="text-slate-500 text-xs capitalize">{tx.type} • {new Date(tx.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-semibold ${tx.type === 'withdrawal' ? 'text-red-400' : 'text-brand-400'}`}>${tx.amount.toLocaleString()}</p>
                  {statusBadge(tx.status)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
