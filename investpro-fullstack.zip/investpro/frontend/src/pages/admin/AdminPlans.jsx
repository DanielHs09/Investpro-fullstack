import React, { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, X, Save } from 'lucide-react';
import { plansAPI } from '../../services/api';
import toast from 'react-hot-toast';

const empty = { name: '', description: '', minAmount: '', maxAmount: '', roiPercent: '', durationDays: '', badge: '', color: '#00C48F', features: '' };

export default function AdminPlans() {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  const load = () => plansAPI.getAll().then(r => setPlans(r.data.plans || [])).catch(() => {}).finally(() => setLoading(false));
  useEffect(load, []);

  const openCreate = () => { setEditing(null); setForm(empty); setModal(true); };
  const openEdit = (p) => { setEditing(p); setForm({ ...p, features: p.features?.join('\n') || '' }); setModal(true); };

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    const payload = { ...form, minAmount: Number(form.minAmount), maxAmount: Number(form.maxAmount), roiPercent: Number(form.roiPercent), durationDays: Number(form.durationDays), features: form.features.split('\n').filter(Boolean) };
    try {
      if (editing) { await plansAPI.update(editing._id, payload); toast.success('Plan updated!'); }
      else { await plansAPI.create(payload); toast.success('Plan created!'); }
      setModal(false); load();
    } catch (err) { toast.error(err.response?.data?.message || 'Save failed'); }
    finally { setSaving(false); }
  };

  const deletePlan = async (id) => {
    if (!window.confirm('Deactivate this plan?')) return;
    try { await plansAPI.delete(id); toast.success('Plan deactivated'); load(); } catch { toast.error('Failed'); }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Investment Plans</h2>
          <p className="text-slate-400 text-sm mt-1">{plans.length} active plans</p>
        </div>
        <button onClick={openCreate} className="gradient-brand text-white text-sm font-semibold px-4 py-2 rounded-xl flex items-center gap-2 hover:opacity-90">
          <Plus size={16} /> Create Plan
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{[...Array(4)].map((_,i) => <div key={i} className="glass rounded-2xl h-40 shimmer" />)}</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plans.map(p => (
            <div key={p._id} className="glass rounded-2xl p-5 border border-white/5 hover:border-brand-500/20 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: p.color + '22' }}>
                    <div className="w-4 h-4 rounded-full" style={{ background: p.color }} />
                  </div>
                  <div>
                    <h3 className="font-bold text-white">{p.name}</h3>
                    {p.badge && <span className="text-xs text-brand-400 font-medium">{p.badge}</span>}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => openEdit(p)} className="p-1.5 glass rounded-lg border border-white/10 text-slate-400 hover:text-brand-400"><Pencil size={14} /></button>
                  <button onClick={() => deletePlan(p._id)} className="p-1.5 glass rounded-lg border border-white/10 text-slate-400 hover:text-red-400"><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                {[['ROI/day', p.roiPercent + '%'], ['Duration', p.durationDays + 'd'], ['Min', '$' + p.minAmount.toLocaleString()], ['Max', '$' + p.maxAmount.toLocaleString()]].map(([l, v]) => (
                  <div key={l} className="bg-white/5 rounded-lg p-2">
                    <p className="text-slate-500 text-xs">{l}</p>
                    <p className="text-white text-sm font-bold">{v}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {modal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4 overflow-y-auto py-8">
          <div className="glass rounded-2xl p-6 border border-white/10 w-full max-w-lg">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-white font-bold text-lg">{editing ? 'Edit Plan' : 'Create Plan'}</h3>
              <button onClick={() => setModal(false)} className="text-slate-400 hover:text-white"><X size={20} /></button>
            </div>
            <form onSubmit={save} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {[['name','Name','text'],['badge','Badge (optional)','text'],['minAmount','Min Amount','number'],['maxAmount','Max Amount','number'],['roiPercent','Daily ROI %','number'],['durationDays','Duration (days)','number']].map(([f,l,t]) => (
                  <div key={f}>
                    <label className="block text-xs text-slate-400 mb-1.5">{l}</label>
                    <input type={t} value={form[f]} onChange={e => setForm({...form, [f]: e.target.value})} required={f !== 'badge'}
                      className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-brand-500/50" />
                  </div>
                ))}
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Description</label>
                <input type="text" value={form.description} onChange={e => setForm({...form, description: e.target.value})} required
                  className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-brand-500/50" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Features (one per line)</label>
                <textarea value={form.features} onChange={e => setForm({...form, features: e.target.value})} rows={3}
                  className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm resize-none focus:outline-none focus:border-brand-500/50" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setModal(false)} className="flex-1 glass border border-white/10 text-slate-400 py-2.5 rounded-xl">Cancel</button>
                <button type="submit" disabled={saving} className="flex-1 gradient-brand text-white font-semibold py-2.5 rounded-xl flex items-center justify-center gap-2 disabled:opacity-50">
                  {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Save size={15} /> Save Plan</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
