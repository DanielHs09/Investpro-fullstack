import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, RefreshCw, Filter } from 'lucide-react';
import { transactionsAPI } from '../../services/api';
import toast from 'react-hot-toast';

export default function AdminTransactions() {
  const [txs, setTxs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ type: '', status: 'pending' });
  const [processing, setProcessing] = useState(null);
  const [noteModal, setNoteModal] = useState(null);
  const [note, setNote] = useState('');

  const load = () => {
    setLoading(true);
    transactionsAPI.getAll(filter).then(r => setTxs(r.data.transactions || [])).catch(() => {}).finally(() => setLoading(false));
  };
  useEffect(load, [filter]);

  const process = async (id, status) => {
    setProcessing(id + status);
    try {
      await transactionsAPI.process(id, { status, adminNote: note });
      toast.success(`Transaction ${status}`);
      setNoteModal(null);
      setNote('');
      load();
    } catch (err) { toast.error('Action failed'); }
    finally { setProcessing(null); }
  };

  const statusBadge = (s) => {
    const m = { pending: 'bg-amber-500/10 text-amber-400', approved: 'bg-brand-500/10 text-brand-400', completed: 'bg-brand-500/10 text-brand-400', rejected: 'bg-red-500/10 text-red-400' };
    return <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${m[s] || ''}`}>{s}</span>;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Transactions</h2>
          <p className="text-slate-400 text-sm mt-1">{txs.length} transactions</p>
        </div>
        <button onClick={load} className="glass border border-white/10 text-slate-400 hover:text-white p-2 rounded-xl"><RefreshCw size={18} /></button>
      </div>

      <div className="flex gap-3 flex-wrap">
        {['', 'deposit', 'withdrawal', 'roi'].map(t => (
          <button key={t} onClick={() => setFilter({...filter, type: t})}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${filter.type === t ? 'gradient-brand text-white' : 'glass border border-white/10 text-slate-400 hover:text-white'}`}>
            {t || 'All Types'}
          </button>
        ))}
        <select value={filter.status} onChange={e => setFilter({...filter, status: e.target.value})}
          className="glass border border-white/10 rounded-xl px-4 py-2 text-sm text-slate-300 focus:outline-none bg-transparent ml-auto">
          <option value="">All Status</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>

      <div className="glass rounded-2xl border border-white/5 overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-4">{[...Array(5)].map((_,i) => <div key={i} className="h-12 shimmer rounded-xl" />)}</div>
        ) : txs.length === 0 ? (
          <div className="text-center py-16 text-slate-400">No transactions found</div>
        ) : (
          <div>
            <div className="grid grid-cols-6 px-5 py-3 border-b border-white/5 text-xs text-slate-500 font-medium uppercase tracking-wider">
              <span className="col-span-2">User</span><span>Type</span><span>Amount</span><span>Status</span><span>Actions</span>
            </div>
            <div className="divide-y divide-white/5">
              {txs.map(tx => (
                <div key={tx._id} className="grid grid-cols-6 px-5 py-4 items-center table-row">
                  <div className="col-span-2">
                    <p className="text-white text-sm font-medium">{tx.user?.firstName} {tx.user?.lastName}</p>
                    <p className="text-slate-500 text-xs">{tx.user?.email}</p>
                    <p className="text-slate-600 text-xs font-mono">{tx.reference}</p>
                  </div>
                  <span className="text-slate-300 text-sm capitalize">{tx.type}</span>
                  <span className={`font-semibold ${tx.type === 'withdrawal' ? 'text-red-400' : 'text-brand-400'}`}>${tx.amount.toLocaleString()}</span>
                  <div>{statusBadge(tx.status)}</div>
                  <div className="flex gap-2">
                    {tx.status === 'pending' && (<>
                      <button onClick={() => process(tx._id, 'approved')} disabled={!!processing}
                        className="p-1.5 bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 rounded-lg transition-colors" title="Approve">
                        <CheckCircle size={16} />
                      </button>
                      <button onClick={() => { setNoteModal(tx._id); setNote(''); }} disabled={!!processing}
                        className="p-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors" title="Reject">
                        <XCircle size={16} />
                      </button>
                    </>)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Reject Modal */}
      {noteModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4">
          <div className="glass rounded-2xl p-6 border border-white/10 w-full max-w-md">
            <h3 className="text-white font-bold mb-3">Reject Transaction</h3>
            <p className="text-slate-400 text-sm mb-4">Optionally provide a reason for rejection:</p>
            <textarea value={note} onChange={e => setNote(e.target.value)} rows={3} placeholder="Reason (optional)"
              className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white resize-none focus:outline-none focus:border-brand-500/50 mb-4" />
            <div className="flex gap-3">
              <button onClick={() => setNoteModal(null)} className="flex-1 glass border border-white/10 text-slate-400 py-2.5 rounded-xl">Cancel</button>
              <button onClick={() => process(noteModal, 'rejected')} className="flex-1 bg-red-500/80 hover:bg-red-500 text-white font-semibold py-2.5 rounded-xl transition-colors">Reject</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
