import React, { useState, useEffect } from 'react';
import { Users, UserCheck, UserX, Search, DollarSign } from 'lucide-react';
import { adminAPI } from '../../services/api';
import toast from 'react-hot-toast';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [creditModal, setCreditModal] = useState(null);
  const [creditAmount, setCreditAmount] = useState('');

  const load = () => {
    adminAPI.getUsers().then(r => setUsers(r.data.users || [])).catch(() => {}).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const toggleStatus = async (user) => {
    try {
      await adminAPI.updateUserStatus(user._id, { isActive: !user.isActive });
      toast.success(`User ${user.isActive ? 'suspended' : 'activated'}`);
      load();
    } catch { toast.error('Failed'); }
  };

  const creditWallet = async () => {
    if (!creditAmount || Number(creditAmount) <= 0) return toast.error('Enter a valid amount');
    try {
      await adminAPI.creditWallet(creditModal._id, { amount: Number(creditAmount), description: 'Admin credit' });
      toast.success(`$${creditAmount} credited to ${creditModal.firstName}'s wallet`);
      setCreditModal(null); setCreditAmount(''); load();
    } catch { toast.error('Failed'); }
  };

  const filtered = users.filter(u => u.role !== 'admin' && (
    u.firstName?.toLowerCase().includes(search.toLowerCase()) ||
    u.lastName?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  ));

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Users</h2>
          <p className="text-slate-400 text-sm mt-1">{filtered.length} registered users</p>
        </div>
      </div>

      <div className="relative">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name or email..."
          className="w-full bg-dark-700 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 max-w-sm" />
      </div>

      <div className="glass rounded-2xl border border-white/5 overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-3">{[...Array(6)].map((_,i) => <div key={i} className="h-12 shimmer rounded-xl" />)}</div>
        ) : (
          <div>
            <div className="grid grid-cols-5 px-5 py-3 border-b border-white/5 text-xs text-slate-500 uppercase tracking-wider font-medium">
              <span className="col-span-2">User</span><span>Balance</span><span>Status</span><span>Actions</span>
            </div>
            <div className="divide-y divide-white/5">
              {filtered.map(user => (
                <div key={user._id} className="grid grid-cols-5 px-5 py-4 items-center table-row">
                  <div className="col-span-2 flex items-center gap-3">
                    <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {user.firstName?.[0]}{user.lastName?.[0]}
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{user.firstName} {user.lastName}</p>
                      <p className="text-slate-500 text-xs">{user.email}</p>
                    </div>
                  </div>
                  <span className="text-brand-400 font-semibold">${(user.walletBalance || 0).toLocaleString()}</span>
                  <span>
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${user.isActive ? 'bg-brand-500/10 text-brand-400' : 'bg-red-500/10 text-red-400'}`}>
                      {user.isActive ? 'Active' : 'Suspended'}
                    </span>
                  </span>
                  <div className="flex gap-2">
                    <button onClick={() => setCreditModal(user)} className="p-1.5 bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 rounded-lg" title="Credit Wallet">
                      <DollarSign size={15} />
                    </button>
                    <button onClick={() => toggleStatus(user)} className={`p-1.5 rounded-lg ${user.isActive ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400' : 'bg-brand-500/10 hover:bg-brand-500/20 text-brand-400'}`}>
                      {user.isActive ? <UserX size={15} /> : <UserCheck size={15} />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Credit Modal */}
      {creditModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4">
          <div className="glass rounded-2xl p-6 border border-white/10 w-full max-w-sm">
            <h3 className="text-white font-bold mb-1">Credit Wallet</h3>
            <p className="text-slate-400 text-sm mb-4">{creditModal.firstName} {creditModal.lastName}</p>
            <div className="relative mb-4">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-semibold">$</span>
              <input type="number" value={creditAmount} onChange={e => setCreditAmount(e.target.value)} placeholder="Amount"
                className="w-full bg-dark-700 border border-white/10 rounded-xl pl-8 pr-4 py-3 text-white focus:outline-none focus:border-brand-500/50" />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setCreditModal(null)} className="flex-1 glass border border-white/10 text-slate-400 py-2.5 rounded-xl">Cancel</button>
              <button onClick={creditWallet} className="flex-1 gradient-brand text-white font-semibold py-2.5 rounded-xl">Credit</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
