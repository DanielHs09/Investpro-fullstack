import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageSquare, Clock } from 'lucide-react';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import toast from 'react-hot-toast';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sending, setSending] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSending(true);
    setTimeout(() => {
      toast.success('Message sent! We will respond within 24 hours.');
      setForm({ name: '', email: '', subject: '', message: '' });
      setSending(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-dark-900 text-white">
      <Navbar />
      <div className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-brand-400 text-sm font-semibold uppercase tracking-widest">Contact Us</span>
            <h1 className="text-4xl md:text-5xl font-bold text-white mt-2 mb-4">Get in Touch</h1>
            <p className="text-slate-400 max-w-xl mx-auto">Our team of experts is available 24/7 to assist you.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Info */}
            <div className="space-y-4">
              {[
                { icon: Mail, title: 'Email Support', info: 'support@investpro.com', sub: 'Response within 2 hours' },
                { icon: Phone, title: 'Phone Support', info: '+1 (555) 000-0000', sub: '24/7 Available' },
                { icon: MapPin, title: 'Headquarters', info: '100 Financial District, NY', sub: 'New York, USA' },
                { icon: Clock, title: 'Business Hours', info: '24/7 Online Support', sub: 'Always available' },
              ].map((item, i) => (
                <div key={i} className="glass rounded-2xl p-5 border border-white/5 flex items-start gap-4">
                  <div className="w-10 h-10 bg-brand-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <item.icon size={18} className="text-brand-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">{item.title}</h3>
                    <p className="text-brand-400 text-sm">{item.info}</p>
                    <p className="text-slate-500 text-xs">{item.sub}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Form */}
            <div className="lg:col-span-2 glass rounded-2xl p-8 border border-white/5">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <MessageSquare size={20} className="text-brand-400" /> Send a Message
              </h2>
              <form onSubmit={submit} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  {['name', 'email'].map(field => (
                    <div key={field}>
                      <label className="block text-sm font-medium text-slate-300 mb-2 capitalize">{field}</label>
                      <input type={field === 'email' ? 'email' : 'text'} value={form[field]} onChange={e => setForm({ ...form, [field]: e.target.value })} required
                        className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 transition-colors" />
                    </div>
                  ))}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Subject</label>
                  <input type="text" value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} required
                    className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 transition-colors" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Message</label>
                  <textarea rows={5} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} required
                    className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 transition-colors resize-none" />
                </div>
                <button type="submit" disabled={sending}
                  className="w-full gradient-brand text-white font-bold py-3.5 rounded-xl glow-brand hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                  {sending ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><Send size={18} /> Send Message</>}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
