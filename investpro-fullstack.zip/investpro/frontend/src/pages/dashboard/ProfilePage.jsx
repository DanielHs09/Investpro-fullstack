import React, { useState } from 'react';
import { User, Lock, Save, Copy, CheckCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { authAPI } from '../../services/api';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { user, updateUser } = useAuth();
  const [profile, setProfile] = useState({ firstName: user?.firstName || '', lastName: user?.lastName || '', phone: user?.phone || '', country: user?.country || '' });
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPw, setSavingPw] = useState(false);
  const [copied, setCopied] = useState(false);

  const saveProfile = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const res = await authAPI.updateProfile(profile);
      updateUser(res.data.user);
      toast.success('Profile updated!');
    } catch (err) { toast.error('Update failed'); }
    finally { setSavingProfile(false); }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    if (passwords.newPassword !== passwords.confirm) return toast.error('Passwords do not match');
    if (passwords.newPassword.length < 6) return toast.error('Password must be at least 6 characters');
    setSavingPw(true);
    try {
      await authAPI.changePassword({ currentPassword: passwords.currentPassword, newPassword: passwords.newPassword });
      toast.success('Password changed!');
      setPasswords({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setSavingPw(false); }
  };

  const copyRef = () => { navigator.clipboard.writeText(user?.referralCode || ''); setCopied(true); setTimeout(() => setCopied(false), 2000); toast.success('Referral code copied!'); };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <h2 className="text-2xl font-bold text-white">My Profile</h2>

      {/* Avatar */}
      <div className="glass rounded-2xl p-6 border border-white/5 flex items-center gap-5">
        <div className="w-16 h-16 gradient-brand rounded-2xl flex items-center justify-center text-white font-bold text-2xl">
          {user?.firstName?.[0]}{user?.lastName?.[0]}
        </div>
        <div>
          <h3 className="font-bold text-white text-lg">{user?.firstName} {user?.lastName}</h3>
          <p className="text-slate-400 text-sm">{user?.email}</p>
          <div className="flex items-center gap-2 mt-2">
            <span className="text-xs text-slate-400">Referral:</span>
            <code className="text-xs text-brand-400 font-mono">{user?.referralCode}</code>
            <button onClick={copyRef} className="text-slate-500 hover:text-brand-400 transition-colors">
              {copied ? <CheckCircle size={13} /> : <Copy size={13} />}
            </button>
          </div>
        </div>
      </div>

      {/* Profile Form */}
      <div className="glass rounded-2xl p-6 border border-white/5">
        <h3 className="font-semibold text-white mb-5 flex items-center gap-2"><User size={18} className="text-brand-400" /> Personal Information</h3>
        <form onSubmit={saveProfile} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {['firstName', 'lastName'].map(f => (
              <div key={f}>
                <label className="block text-sm text-slate-400 mb-2 capitalize">{f.replace(/([A-Z])/g, ' $1')}</label>
                <input type="text" value={profile[f]} onChange={e => setProfile({...profile, [f]: e.target.value})}
                  className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-500/50 transition-colors" />
              </div>
            ))}
          </div>
          {['phone', 'country'].map(f => (
            <div key={f}>
              <label className="block text-sm text-slate-400 mb-2 capitalize">{f}</label>
              <input type="text" value={profile[f]} onChange={e => setProfile({...profile, [f]: e.target.value})}
                className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-500/50 transition-colors" />
            </div>
          ))}
          <button type="submit" disabled={savingProfile}
            className="gradient-brand text-white font-semibold px-6 py-3 rounded-xl hover:opacity-90 transition-all flex items-center gap-2 disabled:opacity-50">
            {savingProfile ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save size={16} />} Save Changes
          </button>
        </form>
      </div>

      {/* Password */}
      <div className="glass rounded-2xl p-6 border border-white/5">
        <h3 className="font-semibold text-white mb-5 flex items-center gap-2"><Lock size={18} className="text-brand-400" /> Change Password</h3>
        <form onSubmit={savePassword} className="space-y-4">
          {[['currentPassword','Current Password'],['newPassword','New Password'],['confirm','Confirm New Password']].map(([f, l]) => (
            <div key={f}>
              <label className="block text-sm text-slate-400 mb-2">{l}</label>
              <input type="password" value={passwords[f]} onChange={e => setPasswords({...passwords, [f]: e.target.value})}
                className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-500/50 transition-colors" />
            </div>
          ))}
          <button type="submit" disabled={savingPw}
            className="glass border border-brand-500/40 text-brand-400 font-semibold px-6 py-3 rounded-xl hover:bg-brand-500/10 transition-all flex items-center gap-2 disabled:opacity-50">
            {savingPw ? <div className="w-4 h-4 border-2 border-brand-400/30 border-t-brand-400 rounded-full animate-spin" /> : <Lock size={16} />} Update Password
          </button>
        </form>
      </div>
    </div>
  );
}
