import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Wallet, TrendingUp, DollarSign, BarChart3, ArrowRight, ArrowDownCircle, ArrowUpCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { transactionsAPI, investmentsAPI } from '../../services/api';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const chartData = [
  { month: 'Jan', value: 400 }, { month: 'Feb', value: 600 }, { month: 'Mar', value: 550 },
  { month: 'Apr', value: 800 }, { month: 'May', value: 900 }, { month: 'Jun', value: 1100 },
  { month: 'Jul', value: 1050 }, { month: 'Aug', value: 1400 }, { month: 'Sep', value: 1300 },
  { month: 'Oct', value: 1600 }, { month: 'Nov', value: 1800 }, { month: 'Dec', value: 2100 },
];

export default function DashboardHome() {
  const { user, refreshUser } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [investments, setInvestments] = useState([]);

  useEffect(() => {
    refreshUser();
    transactionsAPI.getMine({ limit: 5 }).then(r => setTransactions(r.data.transactions || [])).catch(() => {});
    investmentsAPI.getMine().then(r => setInvestments(r.data.investments || [])).catch(() => {});
  }, []);

  const stats = [
    { label: 'Wallet Balance', value: `$${(user?.walletBalance || 0).toLocaleString()}`, icon: Wallet, color: 'text-brand-400 bg-brand-500/10' },
    { label: 'Total Invested', value: `$${(user?.totalInvested || 0).toLocaleString()}`, icon: TrendingUp, color: 'text-blue-400 bg-blue-500/10' },
    { label: 'Total Earnings', value: `$${(user?.totalEarnings || 0).toLocaleString()}`, icon: DollarSign, color: 'text-amber-400 bg-amber-500/10' },
    { label: 'Active Plans', value: investments.filter(i => i.status === 'active').length, icon: BarChart3, color: 'text-purple-400 bg-purple-500/10' },
  ];

  const statusBadge = (s) => {
    const m = { pending: 'bg-amber-500/10 text-amber-400', approved: 'bg-brand-500/10 text-brand-400', completed: 'bg-brand-500/10 text-brand-400', rejected: 'bg-red-500/10 text-red-400', active: 'bg-brand-500/10 text-brand-400' };
    return <span className={`text-xs px-2 py-1 rounded-full font-medium ${m[s] || 'bg-slate-500/10 text-slate-400'}`}>{s}</span>;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Good {new Date().getHours() < 12 ? 'Morning' : 'Evening'}, {user?.firstName} 👋</h2>
          <p className="text-slate-400 text-sm mt-1">Here's your investment overview</p>
        </div>
        <div className="flex gap-3">
          <Link to="/dashboard/deposit" className="gradient-brand text-white text-sm font-semibold px-4 py-2 rounded-xl flex items-center gap-2 hover:opacity-90 transition-all">
            <ArrowDownCircle size={16} /> Deposit
          </Link>
          <Link to="/dashboard/withdraw" className="glass border border-white/10 text-white text-sm font-semibold px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-white/5 transition-all">
            <ArrowUpCircle size={16} /> Withdraw
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="glass rounded-2xl p-5 border border-white/5 stat-card">
            <div className={`w-10 h-10 ${s.color} rounded-xl flex items-center justify-center mb-3`}>
              <s.icon size={18} className={s.color.split(' ')[0]} />
            </div>
            <p className="text-slate-400 text-xs mb-1">{s.label}</p>
            <p className="text-2xl font-bold text-white">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 glass rounded-2xl p-6 border border-white/5">
          <h3 className="font-semibold text-white mb-5">Portfolio Growth</h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00C48F" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#00C48F" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" stroke="#475569" tick={{ fontSize: 11 }} />
              <YAxis stroke="#475569" tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ background: '#0d1530', border: '1px solid rgba(0,196,143,0.2)', borderRadius: '12px', color: '#f1f5f9' }} />
              <Area type="monotone" dataKey="value" stroke="#00C48F" strokeWidth={2} fill="url(#colorVal)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Active Investments */}
        <div className="glass rounded-2xl p-6 border border-white/5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-white">Active Investments</h3>
            <Link to="/dashboard/investments" className="text-brand-400 text-xs hover:text-brand-300"><ArrowRight size={14} /></Link>
          </div>
          {investments.filter(i => i.status === 'active').length === 0 ? (
            <div className="text-center py-8">
              <TrendingUp size={32} className="text-slate-600 mx-auto mb-2" />
              <p className="text-slate-500 text-sm">No active investments</p>
              <Link to="/plans" className="text-brand-400 text-xs mt-2 inline-block">Browse plans →</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {investments.filter(i => i.status === 'active').slice(0,4).map(inv => (
                <div key={inv._id} className="bg-white/5 rounded-xl p-3">
                  <div className="flex justify-between items-start">
                    <p className="text-white text-sm font-medium">{inv.plan?.name}</p>
                    {statusBadge(inv.status)}
                  </div>
                  <p className="text-slate-400 text-xs mt-1">${inv.amount.toLocaleString()} • {inv.roiPercent}% daily</p>
                  <div className="mt-2 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-brand-500 rounded-full" style={{ width: `${Math.min(100, ((Date.now() - new Date(inv.startDate)) / (new Date(inv.endDate) - new Date(inv.startDate))) * 100)}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="glass rounded-2xl border border-white/5 overflow-hidden">
        <div className="p-5 border-b border-white/5 flex items-center justify-between">
          <h3 className="font-semibold text-white">Recent Transactions</h3>
          <Link to="/dashboard/transactions" className="text-brand-400 text-xs hover:text-brand-300 flex items-center gap-1">View All <ArrowRight size={12} /></Link>
        </div>
        {transactions.length === 0 ? (
          <div className="text-center py-10 text-slate-500 text-sm">No transactions yet</div>
        ) : (
          <div className="divide-y divide-white/5">
            {transactions.map(tx => (
              <div key={tx._id} className="px-5 py-4 flex items-center justify-between table-row">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${tx.type === 'deposit' ? 'bg-brand-500/10' : tx.type === 'withdrawal' ? 'bg-red-500/10' : 'bg-blue-500/10'}`}>
                    {tx.type === 'deposit' ? <ArrowDownCircle size={15} className="text-brand-400" /> : <ArrowUpCircle size={15} className="text-red-400" />}
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium capitalize">{tx.type}</p>
                    <p className="text-slate-400 text-xs">{new Date(tx.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-semibold ${tx.type === 'deposit' || tx.type === 'roi' ? 'text-brand-400' : 'text-red-400'}`}>
                    {tx.type === 'deposit' || tx.type === 'roi' ? '+' : '-'}${tx.amount.toLocaleString()}
                  </p>
                  {statusBadge(tx.status)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
