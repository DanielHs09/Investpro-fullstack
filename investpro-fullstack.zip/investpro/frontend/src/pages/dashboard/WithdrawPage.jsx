import React, { useState } from 'react';
import { ArrowUpCircle, CheckCircle, AlertTriangle } from 'lucide-react';
import { transactionsAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

const methods = [
  { id: 'bitcoin', label: 'Bitcoin (BTC)' },
  { id: 'ethereum', label: 'Ethereum (ETH)' },
  { id: 'usdt', label: 'USDT (TRC20)' },
  { id: 'bank', label: 'Bank Transfer' },
];

export default function WithdrawPage() {
  const { user, refreshUser } = useAuth();
  const [form, setForm] = useState({ amount: '', paymentMethod: 'bitcoin', walletAddress: '' });
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!form.walletAddress) return toast.error('Please enter your wallet address');
    if (Number(form.amount) < 50) return toast.error('Minimum withdrawal is $50');
    if (Number(form.amount) > (user?.walletBalance || 0)) return toast.error('Insufficient balance');
    setLoading(true);
    try {
      await transactionsAPI.withdraw({ amount: Number(form.amount), paymentMethod: form.paymentMethod, walletAddress: form.walletAddress });
      await refreshUser();
      toast.success('Withdrawal request submitted!');
      setDone(true);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Withdrawal failed');
    } finally { setLoading(false); }
  };

  if (done) return (
    <div className="max-w-2xl mx-auto">
      <div className="glass rounded-2xl p-10 border border-brand-500/30 text-center">
        <div className="w-16 h-16 bg-brand-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle size={32} className="text-brand-400" />
        </div>
        <h3 className="text-xl font-bold text-white mb-2">Withdrawal Submitted!</h3>
        <p className="text-slate-400 mb-6">Your withdrawal of <span className="text-white font-semibold">${form.amount}</span> is being processed. Typically 1-48 hours.</p>
        <button onClick={() => { setDone(false); setForm({ amount: '', paymentMethod: 'bitcoin', walletAddress: '' }); }}
          className="gradient-brand text-white font-semibold px-6 py-3 rounded-xl hover:opacity-90">New Withdrawal</button>
      </div>
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold text-white">Withdraw Funds</h2>
        <p className="text-slate-400 text-sm mt-1">Request a withdrawal from your wallet</p>
      </div>

      <div className="glass rounded-2xl p-5 border border-brand-500/20 flex items-center justify-between">
        <div>
          <p className="text-slate-400 text-sm">Available Balance</p>
          <p className="text-3xl font-bold text-white">${(user?.walletBalance || 0).toLocaleString()}</p>
        </div>
        <ArrowUpCircle size={32} className="text-brand-400" />
      </div>

      <div className="glass rounded-2xl p-6 border border-white/5 space-y-5">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Amount (USD)</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-semibold">$</span>
            <input type="number" value={form.amount} onChange={e => setForm({...form, amount: e.target.value})} min="50" placeholder="Min $50"
              className="w-full bg-dark-700 border border-white/10 rounded-xl pl-8 pr-4 py-3 text-white focus:outline-none focus:border-brand-500/50" />
          </div>
          <div className="flex gap-2 mt-2">
            {[100, 500, 1000].map(v => (
              <button key={v} type="button" onClick={() => setForm({...form, amount: String(Math.min(v, user?.walletBalance || 0))})}
                className="text-xs px-3 py-1.5 glass rounded-lg border border-white/10 text-slate-400 hover:text-brand-400 hover:border-brand-500/30 transition-all">${v}</button>
            ))}
            <button type="button" onClick={() => setForm({...form, amount: String(user?.walletBalance || 0)})}
              className="text-xs px-3 py-1.5 glass rounded-lg border border-white/10 text-slate-400 hover:text-brand-400 hover:border-brand-500/30 transition-all">Max</button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Payment Method</label>
          <select value={form.paymentMethod} onChange={e => setForm({...form, paymentMethod: e.target.value})}
            className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-500/50">
            {methods.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Your Wallet / Account Address</label>
          <input type="text" value={form.walletAddress} onChange={e => setForm({...form, walletAddress: e.target.value})} placeholder="Enter your receiving address"
            className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50" />
        </div>

        <div className="flex items-start gap-2 bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 text-xs text-amber-400/80">
          <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" />
          <span>Double-check your wallet address. Withdrawals to incorrect addresses cannot be reversed. Processing takes 1-48 hours.</span>
        </div>

        <button onClick={submit} disabled={loading}
          className="w-full gradient-brand text-white font-bold py-3.5 rounded-xl glow-brand hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
          {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><ArrowUpCircle size={18} /> Submit Withdrawal</>}
        </button>
      </div>
    </div>
  );
}
