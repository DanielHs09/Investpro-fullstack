import React, { useState, useEffect } from 'react';
import { History, Filter, ArrowDownCircle, ArrowUpCircle, TrendingUp, RefreshCw } from 'lucide-react';
import { transactionsAPI } from '../../services/api';

export default function TransactionHistoryPage() {
  const [txs, setTxs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ type: '', status: '' });

  const load = () => {
    setLoading(true);
    transactionsAPI.getMine(filter).then(r => setTxs(r.data.transactions || [])).catch(() => {}).finally(() => setLoading(false));
  };
  useEffect(load, [filter]);

  const typeIcon = (t) => {
    if (t === 'deposit') return <ArrowDownCircle size={16} className="text-brand-400" />;
    if (t === 'withdrawal') return <ArrowUpCircle size={16} className="text-red-400" />;
    return <TrendingUp size={16} className="text-blue-400" />;
  };

  const statusBadge = (s) => {
    const m = { pending: 'bg-amber-500/10 text-amber-400', approved: 'bg-brand-500/10 text-brand-400', completed: 'bg-brand-500/10 text-brand-400', rejected: 'bg-red-500/10 text-red-400' };
    return <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${m[s] || 'bg-slate-500/10 text-slate-400'}`}>{s}</span>;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Transaction History</h2>
          <p className="text-slate-400 text-sm mt-1">{txs.length} transactions found</p>
        </div>
        <button onClick={load} className="glass border border-white/10 text-slate-400 hover:text-white p-2 rounded-xl transition-colors">
          <RefreshCw size={18} />
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <select value={filter.type} onChange={e => setFilter({...filter, type: e.target.value})}
          className="glass border border-white/10 rounded-xl px-4 py-2 text-sm text-slate-300 focus:outline-none focus:border-brand-500/50 bg-transparent">
          <option value="">All Types</option>
          <option value="deposit">Deposits</option>
          <option value="withdrawal">Withdrawals</option>
          <option value="investment">Investments</option>
          <option value="roi">ROI</option>
        </select>
        <select value={filter.status} onChange={e => setFilter({...filter, status: e.target.value})}
          className="glass border border-white/10 rounded-xl px-4 py-2 text-sm text-slate-300 focus:outline-none focus:border-brand-500/50 bg-transparent">
          <option value="">All Status</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="completed">Completed</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>

      <div className="glass rounded-2xl border border-white/5 overflow-hidden">
        {loading ? (
          <div className="p-8 space-y-4">{[...Array(5)].map((_, i) => <div key={i} className="h-12 shimmer rounded-xl" />)}</div>
        ) : txs.length === 0 ? (
          <div className="text-center py-16"><History size={40} className="text-slate-600 mx-auto mb-3" /><p className="text-slate-400">No transactions found</p></div>
        ) : (
          <div>
            <div className="grid grid-cols-5 px-5 py-3 border-b border-white/5 text-xs text-slate-500 font-medium uppercase tracking-wider">
              <span>Type</span><span>Reference</span><span>Amount</span><span>Method</span><span>Status</span>
            </div>
            <div className="divide-y divide-white/5">
              {txs.map(tx => (
                <div key={tx._id} className="grid grid-cols-5 px-5 py-4 items-center table-row">
                  <div className="flex items-center gap-2">
                    {typeIcon(tx.type)}
                    <span className="text-white text-sm capitalize">{tx.type}</span>
                  </div>
                  <span className="text-slate-400 text-xs font-mono">{tx.reference}</span>
                  <span className={`font-semibold text-sm ${tx.type === 'withdrawal' ? 'text-red-400' : 'text-brand-400'}`}>
                    {tx.type === 'withdrawal' ? '-' : '+'}${tx.amount.toLocaleString()}
                  </span>
                  <span className="text-slate-400 text-xs capitalize">{tx.paymentMethod || '—'}</span>
                  <div className="flex items-center justify-between">
                    {statusBadge(tx.status)}
                    <span className="text-slate-500 text-xs">{new Date(tx.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
