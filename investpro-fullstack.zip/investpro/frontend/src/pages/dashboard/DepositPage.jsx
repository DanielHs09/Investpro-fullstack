import React, { useState } from 'react';
import { Copy, CheckCircle, ArrowDownCircle } from 'lucide-react';
import { transactionsAPI } from '../../services/api';
import toast from 'react-hot-toast';

const methods = [
  { id: 'bitcoin', label: 'Bitcoin', symbol: 'BTC', address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf', min: 50 },
  { id: 'ethereum', label: 'Ethereum', symbol: 'ETH', address: '0x742d35Cc6634C0532925a3b8D4C9e8d1C2E8b1a2', min: 50 },
  { id: 'usdt', label: 'USDT (TRC20)', symbol: 'USDT', address: 'TLfMR9WxGVhzp5mUdDf7Fs7F8C5e8b1c2D', min: 50 },
];

export default function DepositPage() {
  const [method, setMethod] = useState(methods[0]);
  const [amount, setAmount] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  const copy = () => {
    navigator.clipboard.writeText(method.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Address copied!');
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!amount || Number(amount) < method.min) return toast.error(`Minimum deposit is $${method.min}`);
    setLoading(true);
    try {
      await transactionsAPI.deposit({ amount: Number(amount), paymentMethod: method.id, walletAddress: method.address });
      toast.success('Deposit request submitted! Awaiting confirmation.');
      setStep(3);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Deposit failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold text-white">Deposit Funds</h2>
        <p className="text-slate-400 text-sm mt-1">Add funds to your investment wallet</p>
      </div>

      {step === 3 ? (
        <div className="glass rounded-2xl p-10 border border-brand-500/30 text-center">
          <div className="w-16 h-16 bg-brand-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-brand-400" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Deposit Submitted!</h3>
          <p className="text-slate-400 mb-2">Your deposit of <span className="text-white font-semibold">${amount}</span> via <span className="text-brand-400">{method.label}</span> is being processed.</p>
          <p className="text-slate-500 text-sm mb-6">Typical confirmation time: 1-24 hours</p>
          <button onClick={() => { setStep(1); setAmount(''); }} className="gradient-brand text-white font-semibold px-6 py-3 rounded-xl hover:opacity-90">Make Another Deposit</button>
        </div>
      ) : (
        <div className="glass rounded-2xl border border-white/5 overflow-hidden">
          {/* Method selection */}
          <div className="p-6 border-b border-white/5">
            <h3 className="font-semibold text-white mb-4">Select Payment Method</h3>
            <div className="grid grid-cols-3 gap-3">
              {methods.map(m => (
                <button key={m.id} onClick={() => setMethod(m)}
                  className={`p-3 rounded-xl border text-sm font-medium transition-all ${method.id === m.id ? 'border-brand-500/50 bg-brand-500/10 text-brand-400' : 'border-white/10 text-slate-400 hover:border-brand-500/30'}`}>
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={submit} className="p-6 space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Amount (USD)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-semibold">$</span>
                <input type="number" value={amount} onChange={e => setAmount(e.target.value)} min={method.min} placeholder={`Min $${method.min}`}
                  className="w-full bg-dark-700 border border-white/10 rounded-xl pl-8 pr-4 py-3 text-white focus:outline-none focus:border-brand-500/50" />
              </div>
              <div className="flex gap-2 mt-2">
                {[100, 500, 1000, 5000].map(v => (
                  <button key={v} type="button" onClick={() => setAmount(String(v))}
                    className="text-xs px-3 py-1.5 glass rounded-lg border border-white/10 text-slate-400 hover:text-brand-400 hover:border-brand-500/30 transition-all">${v}</button>
                ))}
              </div>
            </div>

            <div className="bg-dark-700 rounded-xl p-4 border border-white/5">
              <p className="text-xs text-slate-400 mb-2">Send {method.symbol} to this address:</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-xs text-brand-400 font-mono break-all">{method.address}</code>
                <button type="button" onClick={copy} className="p-2 glass rounded-lg border border-white/10 text-slate-400 hover:text-brand-400 flex-shrink-0">
                  {copied ? <CheckCircle size={14} className="text-brand-400" /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 text-xs text-amber-400/80">
              ⚠️ Only send {method.symbol} to this address. Sending other coins may result in permanent loss.
            </div>

            <button type="submit" disabled={loading}
              className="w-full gradient-brand text-white font-bold py-3.5 rounded-xl glow-brand hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <><ArrowDownCircle size={18} /> Confirm Deposit</>}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
