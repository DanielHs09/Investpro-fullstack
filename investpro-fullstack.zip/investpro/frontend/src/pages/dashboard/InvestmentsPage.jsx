import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, ArrowRight, Clock, DollarSign } from 'lucide-react';
import { investmentsAPI } from '../../services/api';

export default function InvestmentsPage() {
  const [investments, setInvestments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    investmentsAPI.getMine().then(r => setInvestments(r.data.investments || [])).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const progress = (inv) => {
    const total = new Date(inv.endDate) - new Date(inv.startDate);
    const elapsed = Date.now() - new Date(inv.startDate);
    return Math.min(100, Math.max(0, (elapsed / total) * 100));
  };

  const statusColor = { active: 'text-brand-400 bg-brand-500/10', completed: 'text-blue-400 bg-blue-500/10', cancelled: 'text-red-400 bg-red-500/10' };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">My Investments</h2>
          <p className="text-slate-400 text-sm mt-1">{investments.length} investment{investments.length !== 1 ? 's' : ''}</p>
        </div>
        <Link to="/plans" className="gradient-brand text-white text-sm font-semibold px-4 py-2 rounded-xl flex items-center gap-2 hover:opacity-90">
          <TrendingUp size={16} /> New Investment
        </Link>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{[...Array(4)].map((_, i) => <div key={i} className="glass rounded-2xl h-48 shimmer" />)}</div>
      ) : investments.length === 0 ? (
        <div className="glass rounded-2xl p-16 border border-white/5 text-center">
          <TrendingUp size={48} className="text-slate-600 mx-auto mb-4" />
          <h3 className="text-white font-semibold text-lg mb-2">No investments yet</h3>
          <p className="text-slate-400 mb-6">Start your investment journey today</p>
          <Link to="/plans" className="gradient-brand text-white font-semibold px-6 py-3 rounded-xl inline-flex items-center gap-2">Browse Plans <ArrowRight size={16} /></Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {investments.map(inv => (
            <div key={inv._id} className="glass rounded-2xl p-5 border border-white/5 hover:border-brand-500/20 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-bold text-white text-lg">{inv.plan?.name || 'Investment'} Plan</h3>
                  <p className="text-slate-400 text-xs">{inv.roiPercent}% daily ROI</p>
                </div>
                <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColor[inv.status]}`}>{inv.status}</span>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="bg-white/5 rounded-xl p-3">
                  <p className="text-slate-400 text-xs mb-1">Invested</p>
                  <p className="text-white font-bold">${inv.amount.toLocaleString()}</p>
                </div>
                <div className="bg-white/5 rounded-xl p-3">
                  <p className="text-slate-400 text-xs mb-1">Expected</p>
                  <p className="text-brand-400 font-bold">${inv.expectedReturn.toLocaleString()}</p>
                </div>
                <div className="bg-white/5 rounded-xl p-3">
                  <p className="text-slate-400 text-xs mb-1">Profit</p>
                  <p className="text-brand-400 font-bold">+${(inv.expectedReturn - inv.amount).toFixed(0)}</p>
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Clock size={11} /> {new Date(inv.startDate).toLocaleDateString()}</span>
                  <span>{progress(inv).toFixed(0)}% complete</span>
                  <span className="flex items-center gap-1"><DollarSign size={11} /> {new Date(inv.endDate).toLocaleDateString()}</span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-brand-600 to-brand-400 rounded-full transition-all" style={{ width: `${progress(inv)}%` }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
