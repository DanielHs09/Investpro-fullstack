import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, TrendingUp, Shield, Zap, Globe, ChevronRight, Star, Users, DollarSign, Award, BarChart3, Lock, Clock } from 'lucide-react';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import PlanCard from '../components/common/PlanCard';
import { plansAPI } from '../services/api';

const Counter = ({ end, prefix = '', suffix = '', duration = 2000 }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = end / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= end) { setCount(end); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [end, duration]);
  return <span>{prefix}{count.toLocaleString()}{suffix}</span>;
};

const features = [
  { icon: Shield, title: 'Bank-Grade Security', desc: '256-bit SSL encryption and multi-factor authentication protect your assets at all times.', color: 'brand' },
  { icon: TrendingUp, title: 'Consistent Returns', desc: 'Our algorithmic trading system delivers consistent ROI regardless of market conditions.', color: 'blue' },
  { icon: Zap, title: 'Instant Processing', desc: 'Lightning-fast deposits and withdrawals processed within 24 hours.', color: 'amber' },
  { icon: Globe, title: 'Global Access', desc: 'Invest from anywhere in the world with our fully digital, borderless platform.', color: 'purple' },
  { icon: BarChart3, title: 'Real-Time Analytics', desc: 'Track every investment with live dashboards, charts, and detailed reports.', color: 'brand' },
  { icon: Lock, title: 'Regulated Platform', desc: 'Fully licensed and compliant with international financial regulations.', color: 'red' },
];

const testimonials = [
  { name: 'Sarah Chen', role: 'Software Engineer', text: 'InvestPro doubled my savings in 6 months. The platform is incredibly intuitive and the returns are exactly as promised.', rating: 5 },
  { name: 'Marcus Williams', role: 'Business Owner', text: "Best investment platform I've used. Transparent, reliable, and their support team is always available.", rating: 5 },
  { name: 'Elena Rodriguez', role: 'Financial Analyst', text: 'As a finance professional, I trust InvestPro with my personal investments. The analytics are world-class.', rating: 5 },
];

export default function HomePage() {
  const [plans, setPlans] = useState([]);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    plansAPI.getAll().then(r => setPlans(r.data.plans?.slice(0, 3) || [])).catch(() => {});
    setTimeout(() => setVisible(true), 100);
  }, []);

  return (
    <div className="min-h-screen bg-dark-900 text-white">
      <Navbar />

      {/* HERO */}
      <section className="relative min-h-screen flex items-center gradient-hero bg-grid-pattern overflow-hidden">
        {/* Floating orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-500/5 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '1s' }} />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
          <div className={`max-w-4xl mx-auto text-center transition-all duration-1000 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full text-sm mb-8 border border-brand-500/20">
              <span className="w-2 h-2 bg-brand-400 rounded-full animate-pulse" />
              <span className="text-brand-400 font-medium">Trusted by 50,000+ investors worldwide</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight tracking-tight">
              Your Money,<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-brand-200">
                Working Harder
              </span>
            </h1>

            <p className="text-slate-400 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
              Professional investment strategies that generate consistent returns. Start with as little as $100 and watch your wealth grow.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Link to="/register" className="gradient-brand text-white font-bold px-8 py-4 rounded-2xl glow-brand hover:opacity-90 transition-all flex items-center gap-2 justify-center text-lg">
                Start Investing <ArrowRight size={20} />
              </Link>
              <Link to="/plans" className="glass border border-white/10 text-white font-semibold px-8 py-4 rounded-2xl hover:bg-white/5 transition-all flex items-center gap-2 justify-center text-lg">
                View Plans <ChevronRight size={20} />
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { value: 50000, label: 'Active Investors', suffix: '+' },
                { value: 2.4, label: 'Assets Managed', prefix: '$', suffix: 'B+' },
                { value: 98, label: 'Success Rate', suffix: '%' },
                { value: 5, label: 'Years Experience', suffix: '+' },
              ].map((s, i) => (
                <div key={i} className="glass rounded-2xl p-5 border border-white/5">
                  <div className="text-2xl md:text-3xl font-extrabold text-white mb-1">
                    <Counter end={typeof s.value === 'number' ? Math.floor(s.value) : s.value} prefix={s.prefix || ''} suffix={s.suffix || ''} />
                  </div>
                  <div className="text-slate-400 text-xs">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-24 bg-dark-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-brand-400 text-sm font-semibold uppercase tracking-widest">Why Choose Us</span>
            <h2 className="text-4xl font-bold text-white mt-2 mb-4">Built for Serious Investors</h2>
            <p className="text-slate-400 max-w-xl mx-auto">Every feature designed to maximize your returns and minimize risk.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => {
              const colorMap = { brand: 'text-brand-400 bg-brand-500/10', blue: 'text-blue-400 bg-blue-500/10', amber: 'text-amber-400 bg-amber-500/10', purple: 'text-purple-400 bg-purple-500/10', red: 'text-red-400 bg-red-500/10' };
              const [tc, bg] = (colorMap[f.color] || colorMap.brand).split(' ');
              return (
                <div key={i} className="glass rounded-2xl p-6 border border-white/5 hover:border-brand-500/20 transition-all group">
                  <div className={`w-12 h-12 rounded-2xl ${bg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <f.icon size={22} className={tc} />
                  </div>
                  <h3 className="font-bold text-white text-lg mb-2">{f.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* PLANS PREVIEW */}
      {plans.length > 0 && (
        <section className="py-24 bg-dark-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="text-brand-400 text-sm font-semibold uppercase tracking-widest">Investment Plans</span>
              <h2 className="text-4xl font-bold text-white mt-2 mb-4">Choose Your Growth Path</h2>
              <p className="text-slate-400 max-w-xl mx-auto">From beginner to elite — plans designed for every investment goal.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
              {plans.map((plan, i) => <PlanCard key={plan._id} plan={plan} featured={plan.badge === 'Popular'} />)}
            </div>
            <div className="text-center">
              <Link to="/plans" className="inline-flex items-center gap-2 text-brand-400 hover:text-brand-300 font-semibold transition-colors">
                View All Plans <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* TESTIMONIALS */}
      <section className="py-24 bg-dark-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-brand-400 text-sm font-semibold uppercase tracking-widest">Testimonials</span>
            <h2 className="text-4xl font-bold text-white mt-2">What Our Investors Say</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <div key={i} className="glass rounded-2xl p-6 border border-white/5 hover:border-brand-500/20 transition-all">
                <div className="flex mb-3">
                  {[...Array(t.rating)].map((_, j) => <Star key={j} size={14} className="text-amber-400 fill-amber-400" />)}
                </div>
                <p className="text-slate-300 text-sm leading-relaxed mb-5 italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 gradient-brand rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {t.name[0]}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{t.name}</p>
                    <p className="text-slate-500 text-xs">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-dark-900">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="glass rounded-3xl p-12 border border-brand-500/20 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-brand-500/5 to-transparent" />
            <div className="relative">
              <h2 className="text-4xl font-bold text-white mb-4">Ready to Grow Your Wealth?</h2>
              <p className="text-slate-400 mb-8 text-lg">Join 50,000+ investors already earning with InvestPro.</p>
              <Link to="/register" className="gradient-brand text-white font-bold px-10 py-4 rounded-2xl glow-brand hover:opacity-90 transition-all inline-flex items-center gap-2 text-lg">
                Create Free Account <ArrowRight size={20} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
