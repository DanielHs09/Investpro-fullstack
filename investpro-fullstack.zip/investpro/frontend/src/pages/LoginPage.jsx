import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, TrendingUp, ArrowRight, Lock, Mail } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) return toast.error('Please fill in all fields');
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      toast.success(`Welcome back, ${user.firstName}!`);
      navigate(user.role === 'admin' ? '/admin' : '/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally { setLoading(false); }
  };

  const fillDemo = (type) => {
    if (type === 'admin') setForm({ email: 'admin@investpro.com', password: 'Admin@123' });
    else setForm({ email: 'john@test.com', password: 'Test@123' });
  };

  return (
    <div className="min-h-screen bg-dark-900 gradient-hero flex items-center justify-center px-4">
      <div className="w-full max-w-md animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center glow-brand">
              <TrendingUp size={20} className="text-white" />
            </div>
            <span className="font-bold text-2xl text-white">Invest<span className="text-brand-400">Pro</span></span>
          </Link>
          <h1 className="text-3xl font-bold text-white mb-2">Welcome Back</h1>
          <p className="text-slate-400">Sign in to access your portfolio</p>
        </div>

        {/* Demo buttons */}
        <div className="flex gap-3 mb-6">
          <button onClick={() => fillDemo('user')} className="flex-1 text-xs py-2 px-3 glass rounded-lg border border-white/10 text-slate-400 hover:text-brand-400 hover:border-brand-500/30 transition-all">
            Demo User
          </button>
          <button onClick={() => fillDemo('admin')} className="flex-1 text-xs py-2 px-3 glass rounded-lg border border-white/10 text-slate-400 hover:text-brand-400 hover:border-brand-500/30 transition-all">
            Demo Admin
          </button>
        </div>

        <div className="glass rounded-2xl p-8 border border-white/5">
          <form onSubmit={submit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input type="email" name="email" value={form.email} onChange={handle} placeholder="you@example.com"
                  className="w-full bg-dark-700 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 transition-colors" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input type={showPw ? 'text' : 'password'} name="password" value={form.password} onChange={handle} placeholder="••••••••"
                  className="w-full bg-dark-700 border border-white/10 rounded-xl pl-10 pr-12 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500/50 transition-colors" />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="w-full gradient-brand text-white font-bold py-3.5 rounded-xl glow-brand hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Sign In <ArrowRight size={18} /></>}
            </button>
          </form>

          <p className="text-center text-slate-400 text-sm mt-6">
            Don't have an account?{' '}
            <Link to="/register" className="text-brand-400 hover:text-brand-300 font-semibold">Create one free</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
