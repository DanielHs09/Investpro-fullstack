import React, { useState, useEffect } from 'react';
import { Calculator, ArrowRight } from 'lucide-react';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import PlanCard from '../components/common/PlanCard';
import { plansAPI } from '../services/api';

export default function PlansPage() {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [calcAmount, setCalcAmount] = useState(1000);
  const [calcPlan, setCalcPlan] = useState(null);

  useEffect(() => {
    plansAPI.getAll().then(r => {
      setPlans(r.data.plans || []);
      if (r.data.plans?.length) setCalcPlan(r.data.plans[1] || r.data.plans[0]);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const calcReturn = calcPlan ? calcAmount * (1 + (calcPlan.roiPercent * calcPlan.durationDays) / 100) : 0;
  const calcProfit = calcReturn - calcAmount;

  return (
    <div className="min-h-screen bg-dark-900 text-white">
      <Navbar />
      <div className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in">
            <span className="text-brand-400 text-sm font-semibold uppercase tracking-widest">Investment Plans</span>
            <h1 className="text-4xl md:text-5xl font-bold text-white mt-2 mb-4">Choose Your Investment Plan</h1>
            <p className="text-slate-400 max-w-2xl mx-auto text-lg">
              Transparent plans with guaranteed returns. Select the plan that matches your financial goals.
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => <div key={i} className="glass rounded-2xl h-96 shimmer" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
              {plans.map(plan => <PlanCard key={plan._id} plan={plan} featured={plan.badge === 'Popular'} />)}
            </div>
          )}

          {/* ROI Calculator */}
          {plans.length > 0 && (
            <div className="glass rounded-3xl p-8 border border-brand-500/20 max-w-3xl mx-auto">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-brand-500/10 rounded-xl flex items-center justify-center">
                  <Calculator size={20} className="text-brand-400" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">ROI Calculator</h2>
                  <p className="text-slate-400 text-sm">Estimate your investment returns</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Investment Amount ($)</label>
                  <input type="number" value={calcAmount} onChange={e => setCalcAmount(Number(e.target.value))} min="100"
                    className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-500/50" />
                  <input type="range" min="100" max="100000" value={calcAmount} onChange={e => setCalcAmount(Number(e.target.value))}
                    className="w-full mt-3 accent-brand-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Select Plan</label>
                  <select value={calcPlan?._id || ''} onChange={e => setCalcPlan(plans.find(p => p._id === e.target.value))}
                    className="w-full bg-dark-700 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-500/50">
                    {plans.map(p => <option key={p._id} value={p._id}>{p.name} — {p.roiPercent}% daily</option>)}
                  </select>
                </div>
              </div>

              {calcPlan && (
                <div className="grid grid-cols-3 gap-4 bg-dark-700 rounded-2xl p-5">
                  <div><p className="text-slate-400 text-xs mb-1">Investment</p><p className="text-white font-bold text-xl">${calcAmount.toLocaleString()}</p></div>
                  <div><p className="text-slate-400 text-xs mb-1">Profit</p><p className="text-brand-400 font-bold text-xl">+${calcProfit.toFixed(2)}</p></div>
                  <div><p className="text-slate-400 text-xs mb-1">Total Return</p><p className="text-white font-bold text-xl">${calcReturn.toFixed(2)}</p></div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
}
