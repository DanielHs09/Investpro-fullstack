import React from 'react';
import { Shield, TrendingUp, Users, Award, CheckCircle } from 'lucide-react';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';

export default function AboutPage() {
  const team = [
    { name: 'James Carter', role: 'CEO & Co-Founder', bio: '15 years in quantitative finance at Goldman Sachs and JP Morgan.' },
    { name: 'Sarah Kim', role: 'CTO', bio: 'Former lead engineer at Coinbase, expert in blockchain and fintech infrastructure.' },
    { name: 'Michael Torres', role: 'Chief Investment Officer', bio: 'Harvard MBA, managed $500M+ portfolios across global markets.' },
    { name: 'Priya Patel', role: 'Head of Compliance', bio: 'Regulatory expert with 12 years in international financial law.' },
  ];

  return (
    <div className="min-h-screen bg-dark-900 text-white">
      <Navbar />
      <div className="pt-24 pb-16">
        {/* Hero */}
        <section className="py-20 text-center gradient-hero">
          <div className="max-w-4xl mx-auto px-4">
            <span className="text-brand-400 text-sm font-semibold uppercase tracking-widest">About InvestPro</span>
            <h1 className="text-5xl font-bold text-white mt-3 mb-6">Redefining Modern<br />Investment Management</h1>
            <p className="text-slate-400 text-xl leading-relaxed">
              Founded in 2019, InvestPro has grown into one of the world's leading digital investment platforms,
              trusted by over 50,000 investors across 120 countries.
            </p>
          </div>
        </section>

        {/* Mission */}
        <section className="py-20 bg-dark-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-white mb-6">Our Mission</h2>
              <p className="text-slate-400 leading-relaxed mb-6">
                We believe that sophisticated investment strategies shouldn't be reserved for the ultra-wealthy.
                InvestPro democratizes access to professional-grade investment tools and strategies.
              </p>
              {['Transparent fee structure with no hidden charges', 'Regulatory compliant across 50+ jurisdictions', 'Algorithmic trading with human oversight', '24/7 automated portfolio monitoring'].map((item, i) => (
                <div key={i} className="flex items-center gap-3 mb-3">
                  <CheckCircle size={18} className="text-brand-400 flex-shrink-0" />
                  <span className="text-slate-300 text-sm">{item}</span>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Users, label: '50,000+', sub: 'Active Investors', color: 'brand' },
                { icon: TrendingUp, label: '$2.4B+', sub: 'Assets Managed', color: 'blue' },
                { icon: Shield, label: '99.9%', sub: 'Uptime SLA', color: 'amber' },
                { icon: Award, label: '15+', sub: 'Industry Awards', color: 'purple' },
              ].map((s, i) => {
                const colorMap = { brand: 'text-brand-400 bg-brand-500/10', blue: 'text-blue-400 bg-blue-500/10', amber: 'text-amber-400 bg-amber-500/10', purple: 'text-purple-400 bg-purple-500/10' };
                const [tc, bg] = (colorMap[s.color]).split(' ');
                return (
                  <div key={i} className="glass rounded-2xl p-5 border border-white/5 text-center">
                    <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                      <s.icon size={20} className={tc} />
                    </div>
                    <p className="text-2xl font-bold text-white">{s.label}</p>
                    <p className="text-slate-400 text-xs">{s.sub}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Team */}
        <section className="py-20 bg-dark-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-white mb-4">Leadership Team</h2>
              <p className="text-slate-400">World-class experts with decades of combined experience.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {team.map((member, i) => (
                <div key={i} className="glass rounded-2xl p-6 border border-white/5 text-center hover:border-brand-500/20 transition-all group">
                  <div className="w-16 h-16 gradient-brand rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <span className="text-white font-bold text-xl">{member.name.split(' ').map(n => n[0]).join('')}</span>
                  </div>
                  <h3 className="font-bold text-white mb-1">{member.name}</h3>
                  <p className="text-brand-400 text-xs font-medium mb-3">{member.role}</p>
                  <p className="text-slate-400 text-xs leading-relaxed">{member.bio}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
}
