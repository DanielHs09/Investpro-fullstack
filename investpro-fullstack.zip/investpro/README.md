<div align="center">

# 💹 InvestPro

### A Modern Full-Stack Investment Platform

[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![React](https://img.shields.io/badge/React-18-blue.svg)](https://reactjs.org/)
[![Node.js](https://img.shields.io/badge/Node.js-18+-green.svg)](https://nodejs.org/)
[![MongoDB](https://img.shields.io/badge/MongoDB-8.0-green.svg)](https://mongodb.com/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-3-blue.svg)](https://tailwindcss.com/)

A professional fintech investment platform with JWT authentication, user dashboard, admin panel, deposit/withdrawal system, and investment plan management.

[Live Demo](#) · [Report Bug](../../issues) · [Request Feature](../../issues)

</div>

---

## 📸 Screenshots

| Home Page | User Dashboard | Admin Panel |
|-----------|---------------|-------------|
| ![Home](#) | ![Dashboard](#) | ![Admin](#) |

---

## ✨ Features

### User
- 🔐 JWT Authentication (register, login, profile)
- 💰 Wallet balance system
- 📈 Investment plan selection & tracking
- 💳 Deposit requests (Bitcoin, Ethereum, USDT)
- 💸 Withdrawal requests
- 📊 Transaction history with filters
- 🔔 Notifications
- 🌙 Dark / Light mode

### Admin
- 📋 Dashboard with platform statistics
- ✅ Approve / reject deposits and withdrawals
- 👥 User management (activate, suspend, credit wallet)
- 📦 Investment plan management (create, edit, delete)
- 📉 Revenue and activity charts

---

## 🛠 Tech Stack

| Layer      | Technology                          |
|------------|-------------------------------------|
| Frontend   | React 18, React Router v6, Tailwind CSS |
| Charts     | Recharts                            |
| HTTP       | Axios                               |
| Backend    | Node.js, Express 4                  |
| Database   | MongoDB, Mongoose                   |
| Auth       | JWT, bcryptjs                       |
| Security   | Helmet, CORS, express-rate-limit    |
| Hosting    | Netlify (frontend), Render (backend) |

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- MongoDB (local or [MongoDB Atlas](https://cloud.mongodb.com))
- Git

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/investpro-fullstack.git
cd investpro-fullstack
```

### 2. Backend setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/investpro
JWT_SECRET=your_super_secret_key_here
JWT_EXPIRE=7d
NODE_ENV=development
CLIENT_URL=http://localhost:3000
```

Seed sample data:

```bash
npm run seed
```

Start the server:

```bash
npm run dev
```

API runs at `http://localhost:5000`

### 3. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env
```

Edit `.env`:

```env
REACT_APP_API_URL=http://localhost:5000/api
```

Start the app:

```bash
npm start
```

App runs at `http://localhost:3000`

---

## 🔑 Demo Credentials

| Role  | Email                 | Password  |
|-------|-----------------------|-----------|
| Admin | admin@investpro.com   | Admin@123 |
| User  | john@test.com         | Test@123  |
| User  | jane@test.com         | Test@123  |

---

## 📡 API Reference

### Auth
| Method | Endpoint             | Access  | Description       |
|--------|----------------------|---------|-------------------|
| POST   | /api/auth/register   | Public  | Register user     |
| POST   | /api/auth/login      | Public  | Login             |
| GET    | /api/auth/me         | Private | Get profile       |
| PUT    | /api/auth/profile    | Private | Update profile    |
| PUT    | /api/auth/password   | Private | Change password   |

### Plans
| Method | Endpoint         | Access | Description        |
|--------|------------------|--------|--------------------|
| GET    | /api/plans       | Public | Get all plans      |
| POST   | /api/plans       | Admin  | Create plan        |
| PUT    | /api/plans/:id   | Admin  | Update plan        |
| DELETE | /api/plans/:id   | Admin  | Deactivate plan    |

### Investments
| Method | Endpoint               | Access  | Description         |
|--------|------------------------|---------|---------------------|
| POST   | /api/investments       | Private | Create investment   |
| GET    | /api/investments/my    | Private | My investments      |
| GET    | /api/investments/all   | Admin   | All investments     |

### Transactions
| Method | Endpoint                       | Access  | Description        |
|--------|--------------------------------|---------|--------------------|
| POST   | /api/transactions/deposit      | Private | Submit deposit     |
| POST   | /api/transactions/withdrawal   | Private | Submit withdrawal  |
| GET    | /api/transactions/my           | Private | My transactions    |
| GET    | /api/transactions/all          | Admin   | All transactions   |
| PUT    | /api/transactions/:id/process  | Admin   | Approve / reject   |

### Admin
| Method | Endpoint                      | Access | Description         |
|--------|-------------------------------|--------|---------------------|
| GET    | /api/admin/stats              | Admin  | Dashboard stats     |
| GET    | /api/admin/users              | Admin  | All users           |
| PUT    | /api/admin/users/:id/status   | Admin  | Toggle user status  |
| POST   | /api/admin/users/:id/credit   | Admin  | Credit user wallet  |

---

## 📁 Project Structure

```
investpro-fullstack/
├── backend/
│   └── src/
│       ├── controllers/     # Business logic
│       ├── middleware/       # Auth & validation
│       ├── models/           # Mongoose schemas
│       ├── routes/           # API routes
│       ├── utils/            # Seeder
│       └── server.js         # Entry point
├── frontend/
│   └── src/
│       ├── components/       # Navbar, Footer, Cards
│       │   ├── admin/
│       │   ├── common/
│       │   └── dashboard/
│       ├── context/          # Auth & Theme context
│       ├── pages/            # All pages
│       │   ├── admin/
│       │   └── dashboard/
│       ├── services/         # Axios API calls
│       ├── App.jsx
│       └── index.css
├── .gitignore
├── LICENSE
└── README.md
```

---

## ☁️ Deployment

### Backend → [Render.com](https://render.com) (Free)

1. Push to GitHub
2. New Web Service → connect repo → set root to `backend/`
3. Build command: `npm install`
4. Start command: `node src/server.js`
5. Add all `.env` variables
6. Deploy and copy your service URL

### Frontend → [Netlify](https://netlify.com)

1. New site from Git → connect repo → set base to `frontend/`
2. Build command: `npm run build`
3. Publish directory: `build`
4. Add environment variable:
   ```
   REACT_APP_API_URL = https://your-render-service.onrender.com/api
   ```
5. Deploy — `_redirects` file already handles SPA routing

---

## 🔒 Security

- Passwords hashed with **bcrypt** (12 rounds)
- **JWT** tokens with configurable expiry
- **Helmet.js** HTTP security headers
- **CORS** restricted to frontend origin
- **Rate limiting** — 100 requests per 15 minutes
- Protected routes on both frontend and backend
- Admin-only endpoints with role-based middleware

---

## 🤝 Contributing

1. Fork the project
2. Create your branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

Distributed under the MIT License. See [LICENSE](LICENSE) for details.

---

<div align="center">
Made with ❤️ by the InvestPro Team
</div>
