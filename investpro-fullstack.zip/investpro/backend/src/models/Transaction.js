const mongoose = require('mongoose');

const TransactionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.ObjectId, ref: 'User', required: true },
  type: { type: String, enum: ['deposit', 'withdrawal', 'roi', 'investment', 'referral'], required: true },
  amount: { type: Number, required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected', 'completed'], default: 'pending' },
  description: { type: String },
  reference: { type: String, unique: true },
  paymentMethod: { type: String },
  walletAddress: { type: String },
  adminNote: { type: String },
  processedBy: { type: mongoose.Schema.ObjectId, ref: 'User' },
  processedAt: { type: Date },
  investment: { type: mongoose.Schema.ObjectId, ref: 'Investment' },
  createdAt: { type: Date, default: Date.now }
});

TransactionSchema.pre('save', function(next) {
  if (!this.reference) {
    this.reference = 'TXN' + Date.now() + Math.random().toString(36).substring(2, 6).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('Transaction', TransactionSchema);
