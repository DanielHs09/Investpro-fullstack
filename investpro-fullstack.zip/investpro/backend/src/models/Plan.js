const mongoose = require('mongoose');

const PlanSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  minAmount: { type: Number, required: true },
  maxAmount: { type: Number, required: true },
  roiPercent: { type: Number, required: true },
  durationDays: { type: Number, required: true },
  features: [String],
  isActive: { type: Boolean, default: true },
  badge: { type: String, default: '' },
  color: { type: String, default: '#00D4AA' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Plan', PlanSchema);
