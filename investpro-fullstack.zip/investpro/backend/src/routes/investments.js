const express = require('express');
const router = express.Router();
const { createInvestment, getMyInvestments, getAllInvestments } = require('../controllers/investmentController');
const { protect, authorize } = require('../middleware/auth');

router.post('/', protect, createInvestment);
router.get('/my', protect, getMyInvestments);
router.get('/all', protect, authorize('admin'), getAllInvestments);

module.exports = router;
