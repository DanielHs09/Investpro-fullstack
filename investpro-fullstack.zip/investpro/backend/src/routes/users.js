const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const User = require('../models/User');

// Mark notification as read
router.put('/notifications/:notifId/read', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    const notif = user.notifications.id(req.params.notifId);
    if (notif) { notif.read = true; await user.save(); }
    res.json({ success: true });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// Mark all notifications read
router.put('/notifications/read-all', protect, async (req, res) => {
  try {
    await User.updateOne({ _id: req.user.id }, { $set: { 'notifications.$[].read': true } });
    res.json({ success: true });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

module.exports = router;
