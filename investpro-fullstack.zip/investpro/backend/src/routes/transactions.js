const express = require('express');
const router = express.Router();
const { createDeposit, createWithdrawal, getMyTransactions, getAllTransactions, processTransaction } = require('../controllers/transactionController');
const { protect, authorize } = require('../middleware/auth');

router.post('/deposit', protect, createDeposit);
router.post('/withdrawal', protect, createWithdrawal);
router.get('/my', protect, getMyTransactions);
router.get('/all', protect, authorize('admin'), getAllTransactions);
router.put('/:id/process', protect, authorize('admin'), processTransaction);

module.exports = router;
