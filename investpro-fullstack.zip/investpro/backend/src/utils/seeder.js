const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Plan = require('../models/Plan');
const Transaction = require('../models/Transaction');

const seed = async () => {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/investpro');
  console.log('Connected to MongoDB');

  // Clear existing
  await Promise.all([User.deleteMany(), Plan.deleteMany(), Transaction.deleteMany()]);

  // Create admin
  const admin = await User.create({
    firstName: 'Admin', lastName: 'User', email: 'admin@investpro.com',
    password: 'Admin@123', role: 'admin', walletBalance: 50000,
    totalEarnings: 12000, isVerified: true
  });

  // Create test users
  const users = await User.create([
    { firstName: 'John', lastName: 'Doe', email: 'john@test.com', password: 'Test@123', walletBalance: 5000, totalInvested: 2500, totalEarnings: 875 },
    { firstName: 'Jane', lastName: 'Smith', email: 'jane@test.com', password: 'Test@123', walletBalance: 12500, totalInvested: 10000, totalEarnings: 3500 },
    { firstName: 'Alex', lastName: 'Johnson', email: 'alex@test.com', password: 'Test@123', walletBalance: 1200, totalInvested: 500, totalEarnings: 175 },
  ]);

  // Create plans
  const plans = await Plan.create([
    { name: 'Starter', description: 'Perfect for new investors', minAmount: 100, maxAmount: 999, roiPercent: 1.5, durationDays: 30, badge: '', color: '#6366f1', features: ['1.5% Daily ROI', '30-Day Duration', 'Min $100 Investment', 'Email Support', 'Basic Analytics'] },
    { name: 'Growth', description: 'Our most popular plan', minAmount: 1000, maxAmount: 4999, roiPercent: 2.5, durationDays: 45, badge: 'Popular', color: '#00D4AA', features: ['2.5% Daily ROI', '45-Day Duration', 'Min $1,000 Investment', 'Priority Support', 'Advanced Analytics', 'Weekly Reports'] },
    { name: 'Professional', description: 'For serious investors', minAmount: 5000, maxAmount: 24999, roiPercent: 3.5, durationDays: 60, badge: 'Best Value', color: '#f59e0b', features: ['3.5% Daily ROI', '60-Day Duration', 'Min $5,000 Investment', '24/7 Support', 'Portfolio Management', 'Daily Reports', 'Risk Analysis'] },
    { name: 'Elite', description: 'Maximum returns for high-net-worth investors', minAmount: 25000, maxAmount: 500000, roiPercent: 5, durationDays: 90, badge: 'Premium', color: '#ef4444', features: ['5% Daily ROI', '90-Day Duration', 'Min $25,000 Investment', 'Dedicated Account Manager', 'Full Portfolio Suite', 'Real-time Reports', 'Priority Withdrawals', 'VIP Events'] },
  ]);

  // Create sample transactions
  await Transaction.create([
    { user: users[0]._id, type: 'deposit', amount: 2500, status: 'approved', paymentMethod: 'bitcoin', description: 'Bitcoin deposit' },
    { user: users[0]._id, type: 'investment', amount: 1000, status: 'completed', description: 'Growth Plan investment' },
    { user: users[1]._id, type: 'deposit', amount: 10000, status: 'approved', paymentMethod: 'usdt', description: 'USDT deposit' },
    { user: users[1]._id, type: 'withdrawal', amount: 1500, status: 'pending', paymentMethod: 'bitcoin', description: 'Bitcoin withdrawal' },
    { user: users[2]._id, type: 'deposit', amount: 500, status: 'pending', paymentMethod: 'ethereum', description: 'ETH deposit' },
  ]);

  console.log('\n=== SEED COMPLETE ===');
  console.log('Admin: admin@investpro.com / Admin@123');
  console.log('User:  john@test.com / Test@123');
  console.log('User:  jane@test.com / Test@123');
  console.log('====================\n');
  process.exit(0);
};

seed().catch(err => { console.error(err); process.exit(1); });
