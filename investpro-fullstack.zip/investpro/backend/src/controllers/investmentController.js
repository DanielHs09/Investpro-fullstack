const Investment = require('../models/Investment');
const Plan = require('../models/Plan');
const Transaction = require('../models/Transaction');
const User = require('../models/User');

// @desc  Create investment
exports.createInvestment = async (req, res) => {
  try {
    const { planId, amount } = req.body;
    const plan = await Plan.findById(planId);
    if (!plan) return res.status(404).json({ success: false, message: 'Plan not found' });
    if (amount < plan.minAmount || amount > plan.maxAmount) {
      return res.status(400).json({ success: false, message: `Amount must be between $${plan.minAmount} and $${plan.maxAmount}` });
    }

    const user = await User.findById(req.user.id);
    if (user.walletBalance < amount) {
      return res.status(400).json({ success: false, message: 'Insufficient wallet balance' });
    }

    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.durationDays);
    const expectedReturn = amount * (1 + (plan.roiPercent * plan.durationDays) / 100);

    const investment = await Investment.create({
      user: req.user.id, plan: planId, amount,
      endDate, roiPercent: plan.roiPercent, expectedReturn
    });

    // Deduct from wallet
    user.walletBalance -= amount;
    user.totalInvested += amount;
    await user.save({ validateBeforeSave: false });

    // Record transaction
    await Transaction.create({
      user: req.user.id, type: 'investment', amount,
      status: 'completed', description: `Invested in ${plan.name} plan`,
      investment: investment._id
    });

    res.status(201).json({ success: true, investment: await investment.populate('plan') });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Get user investments
exports.getMyInvestments = async (req, res) => {
  try {
    const investments = await Investment.find({ user: req.user.id })
      .populate('plan', 'name roiPercent durationDays color')
      .sort('-createdAt');
    res.json({ success: true, count: investments.length, investments });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Get all investments (admin)
exports.getAllInvestments = async (req, res) => {
  try {
    const investments = await Investment.find()
      .populate('user', 'firstName lastName email')
      .populate('plan', 'name roiPercent')
      .sort('-createdAt');
    res.json({ success: true, count: investments.length, investments });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
