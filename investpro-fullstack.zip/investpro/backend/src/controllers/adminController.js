const User = require('../models/User');
const Transaction = require('../models/Transaction');
const Investment = require('../models/Investment');
const Plan = require('../models/Plan');

// @desc  Admin dashboard stats
exports.getDashboardStats = async (req, res) => {
  try {
    const [totalUsers, totalTransactions, allInvestments, plans] = await Promise.all([
      User.countDocuments({ role: 'user' }),
      Transaction.find(),
      Investment.find(),
      Plan.countDocuments({ isActive: true })
    ]);

    const pendingDeposits = await Transaction.countDocuments({ type: 'deposit', status: 'pending' });
    const pendingWithdrawals = await Transaction.countDocuments({ type: 'withdrawal', status: 'pending' });

    const totalDeposited = allInvestments.reduce((s, i) => s + i.amount, 0);
    const totalRevenue = allInvestments.filter(i => i.status === 'completed')
      .reduce((s, i) => s + (i.expectedReturn - i.amount), 0);

    const recentUsers = await User.find({ role: 'user' }).sort('-createdAt').limit(5).select('firstName lastName email createdAt walletBalance');
    const recentTransactions = await Transaction.find().sort('-createdAt').limit(10).populate('user', 'firstName lastName email');

    res.json({
      success: true,
      stats: { totalUsers, totalInvestments: allInvestments.length, totalDeposited, pendingDeposits, pendingWithdrawals, totalRevenue, activePlans: plans },
      recentUsers, recentTransactions
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Get all users
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().sort('-createdAt');
    res.json({ success: true, count: users.length, users });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Update user status
exports.updateUserStatus = async (req, res) => {
  try {
    const { isActive } = req.body;
    const user = await User.findByIdAndUpdate(req.params.id, { isActive }, { new: true });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Credit user wallet manually
exports.creditWallet = async (req, res) => {
  try {
    const { amount, description } = req.body;
    const user = await User.findByIdAndUpdate(req.params.id, { $inc: { walletBalance: amount } }, { new: true });
    await Transaction.create({
      user: req.params.id, type: 'roi', amount, status: 'completed',
      description: description || 'Admin credit'
    });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
