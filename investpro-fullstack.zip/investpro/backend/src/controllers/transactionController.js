const Transaction = require('../models/Transaction');
const User = require('../models/User');

// @desc  Create deposit
exports.createDeposit = async (req, res) => {
  try {
    const { amount, paymentMethod, walletAddress } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ success: false, message: 'Valid amount required' });

    const transaction = await Transaction.create({
      user: req.user.id, type: 'deposit', amount,
      paymentMethod, walletAddress,
      description: `Deposit via ${paymentMethod}`, status: 'pending'
    });

    // Notify user
    await User.findByIdAndUpdate(req.user.id, {
      $push: { notifications: { message: `Deposit of $${amount} submitted. Awaiting confirmation.`, type: 'info' } }
    });

    res.status(201).json({ success: true, transaction });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Create withdrawal
exports.createWithdrawal = async (req, res) => {
  try {
    const { amount, paymentMethod, walletAddress } = req.body;
    const user = await User.findById(req.user.id);

    if (!amount || amount <= 0) return res.status(400).json({ success: false, message: 'Valid amount required' });
    if (user.walletBalance < amount) return res.status(400).json({ success: false, message: 'Insufficient balance' });
    if (amount < 50) return res.status(400).json({ success: false, message: 'Minimum withdrawal is $50' });

    // Reserve balance
    user.walletBalance -= amount;
    await user.save({ validateBeforeSave: false });

    const transaction = await Transaction.create({
      user: req.user.id, type: 'withdrawal', amount,
      paymentMethod, walletAddress,
      description: `Withdrawal via ${paymentMethod}`, status: 'pending'
    });

    res.status(201).json({ success: true, transaction });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Get my transactions
exports.getMyTransactions = async (req, res) => {
  try {
    const { type, status, limit = 50 } = req.query;
    const filter = { user: req.user.id };
    if (type) filter.type = type;
    if (status) filter.status = status;

    const transactions = await Transaction.find(filter)
      .sort('-createdAt')
      .limit(parseInt(limit));
    res.json({ success: true, count: transactions.length, transactions });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Get all transactions (admin)
exports.getAllTransactions = async (req, res) => {
  try {
    const { type, status } = req.query;
    const filter = {};
    if (type) filter.type = type;
    if (status) filter.status = status;

    const transactions = await Transaction.find(filter)
      .populate('user', 'firstName lastName email')
      .sort('-createdAt');
    res.json({ success: true, count: transactions.length, transactions });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc  Approve or reject transaction (admin)
exports.processTransaction = async (req, res) => {
  try {
    const { status, adminNote } = req.body;
    const transaction = await Transaction.findById(req.params.id).populate('user');
    if (!transaction) return res.status(404).json({ success: false, message: 'Transaction not found' });
    if (!['approved', 'rejected'].includes(status)) return res.status(400).json({ success: false, message: 'Invalid status' });

    transaction.status = status;
    transaction.adminNote = adminNote;
    transaction.processedBy = req.user.id;
    transaction.processedAt = Date.now();
    await transaction.save();

    // Update user balance for approved deposits
    if (transaction.type === 'deposit' && status === 'approved') {
      await User.findByIdAndUpdate(transaction.user._id, {
        $inc: { walletBalance: transaction.amount },
        $push: { notifications: { message: `Your deposit of $${transaction.amount} has been approved!`, type: 'success' } }
      });
    }
    // Refund on rejected withdrawal
    if (transaction.type === 'withdrawal' && status === 'rejected') {
      await User.findByIdAndUpdate(transaction.user._id, {
        $inc: { walletBalance: transaction.amount },
        $push: { notifications: { message: `Your withdrawal of $${transaction.amount} was rejected. Funds returned.`, type: 'warning' } }
      });
    }
    if (transaction.type === 'withdrawal' && status === 'approved') {
      await User.findByIdAndUpdate(transaction.user._id, {
        $push: { notifications: { message: `Your withdrawal of $${transaction.amount} has been processed!`, type: 'success' } }
      });
    }

    res.json({ success: true, transaction });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
